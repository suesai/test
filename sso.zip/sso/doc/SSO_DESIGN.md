# Co-Claw 单点登录设计

## 1. 整体架构

### 1.1 插件形态

- **实现方式**：SSO 实现为 **OpenClaw 扩展插件**，复用既有插件机制（`openclaw.plugin.json`、`package.json` 的 `openclaw.extensions` 等约定）
- **源码路径**：[`apps/app-desktop/openclaw-resources/extensions/sso/`](apps/app-desktop/openclaw-resources/extensions/sso/)
- **启用规则**：
  - 打包时纳入插件 + 对应局点配置文件（`sso.json`）→ 启用 SSO
  - 否则 → 无 SSO 能力
- **加载时机**：Gateway 启动时注册 `gateway_start` 钩子，回调中执行 `runSso`

### 1.2 认证链路

| 局点 | 认证流程 | 凭证存储 | 失败策略 |
|------|---------|---------|---------|
| **杭研** | getToken → checkToken（两步） | 内存加密（token、nickname、phone） | 退出 Electron + Gateway |
| **联通** | getUnionAiKey（一步） | 内存加密 + 写入 `openclaw.json` | 继续运行，支持手动重试 |

- **联通密钥**：RSA 公钥/私钥配置在 `sso.json` 中，不硬编码
- **加密方式**：统一使用 SDK 内置 `aesGcmEncrypt`/`aesGcmDecrypt`

### 1.3 失败处理矩阵

| 场景 | Electron | Gateway | 日志 |
|------|---------|---------|------|
| `sso.json` 不存在 | 继续 | 继续 | 告警 |
| 配置文件无效/字段缺失 | 展示错误 → 退出 | 停止 | 错误 |
| 杭研认证失败 | 展示错误 → 退出 | 停止 | 错误 |
| 联通认证失败 | 继续 | 继续 | 错误 |

## 2. 详细设计

### 2.1 目录结构

```
apps/app-desktop/openclaw-resources/extensions/sso/
  package.json
  openclaw.plugin.json
  sso.json                        # 局点配置文件（打包时带入）
  index.ts                        # 插件入口：注册 gateway_start、对外接口
  src/
    config.ts                     # loadSsoJson：加载并校验 sso.json
    log.ts                        # 日志系统（写入 ~/.openclaw/logs/sso.log）+ 埋点上报
    errors.ts                     # 错误类型定义
    credential.ts                 # 凭证管理（内存加密）
    platform/
      index.ts                    # 导出 getVmid、getHostSerialNumber
      vmid.ts                     # Windows/Linux 的 vmid 获取
      host-serial.ts              # 各 OS 主机序列号
    site/
      index.ts                    # runSite：按 site 分派到各局点
      http-helpers.ts             # 通用 HTTP 重试、URL 辅助
      hangyan/
        provider.ts               # runHangyanSso 入口
        get-token.ts              # POST /terminal/token/sso/getToken/v1
        check-token.ts            # POST /cube/external/checkToken
        hmac.ts                   # HMAC 签名工具
        host-snapshot.ts          # 主机信息快照（OS、序列号等）
      unicom/
        provider.ts               # runUnicomSso 入口
        get-union-ai-key.ts       # POST /openapi/user/getUnionAiKeyByResourceId
```

### 2.2 执行流程

```
Gateway 启动
  ↓
加载 SSO 插件
  ↓
执行 runSso
  ├─ loadSsoJson()                # 第 1 步：加载配置（文件不存在 → 告警跳过）
  ├─ initLog(cfg.debug)           # 第 2 步：初始化日志
  ├─ clearCredential()            # 第 3 步：清空凭证
  ├─ getVmid()                    # 第 4 步：读取 vmid
  └─ runSite(site, vmid)          # 第 5 步：局点分派
       ├─ runHangyanSso()         # 杭研：getToken → checkToken
       └─ runUnicomSso()          # 联通：getUnionAiKeyByResourceId
```

### 2.3 配置设计

**位置**：插件目录内 `sso.json`（不同局点使用不同配置文件）

**通用字段**（所有局点）：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `site` | string | - | 局点标识（`hangyan` / `unicom`），**必选** |
| `baseUrl` | string | - | API Base URL |
| `httpTimeoutMs` | number | 5000 | HTTP 超时（ms），上限 32000 |
| `httpRetryCount` | number | 4 | HTTP 重试次数（含第 1 次），上限 32 |
| `debug` | boolean | false | 开启 debug 日志 |

**杭研特有字段**（`site: "hangyan"`）：

| 字段 | 说明 |
|------|------|
| `getTokenAppKey` | getToken API 的应用标识（AppKey），放在请求头 `X-SOHO-AppKey` 中传输（**配置文件中为 AES-GCM 加密字符串**） |
| `getTokenAppSecret` | getToken API 的签名密钥（AppSecret），用于 HMAC-SHA256 签名计算（**配置文件中为 AES-GCM 加密字符串**） |
| `checkTokenAppKey` | checkToken API 的应用标识（AppKey），放在请求头 `X-SOHOJS-Key` 中传输（**配置文件中为 AES-GCM 加密字符串**） |
| `checkTokenAppSecret` | checkToken API 的签名密钥（AppSecret），用于 HMAC-SHA256 签名计算（**配置文件中为 AES-GCM 加密字符串**） |

**注意**：`loadSsoJson` 不强制检查 `baseUrl` 和 HMAC 四键是否存在；进入 **`runHangyanSso`** 时这些字段须齐全，否则 **`SsoConfigError`**。

**联通特有字段**（`site: "unicom"`）：

| 字段 | 说明 |
|------|------|
| `rsaPublicKey` | RSA 公钥（Base64 PEM 格式，加密请求，**配置文件中为 AES-GCM 加密字符串**） |
| `rsaPrivateKey` | RSA 私钥（Base64 PEM 格式，解密响应，**配置文件中为 AES-GCM 加密字符串**） |

**注意**：`loadSsoJson` 不强制检查 `baseUrl` 和 RSA 密钥是否存在；进入 **`runUnicomSso`** 时这些字段须齐全，否则 **`SsoConfigError`**。

**杭研配置示例**：

```json
{
  "site": "hangyan",
  "baseUrl": "https://example.com",
  "getTokenAppKey": "ENCv1:<base64 加密字符串>",
  "getTokenAppSecret": "ENCv1:<base64 加密字符串>",
  "checkTokenAppKey": "ENCv1:<base64 加密字符串>",
  "checkTokenAppSecret": "ENCv1:<base64 加密字符串>"
}
```

**联通配置示例**：

```json
{
  "site": "unicom",
  "baseUrl": "https://example.com",
  "rsaPublicKey": "ENCv1:<base64 加密字符串>",
  "rsaPrivateKey": "ENCv1:<base64 加密字符串>"
}
```

**说明**：所有密钥字段在配置文件中均使用 AES-256-GCM 加密存储（`openclaw/plugin-sdk/coclaw` 的 `aesGcmEncrypt`），加载时自动解密。

### 2.4 对外接口

通过 Gateway RPC 提供接口：

#### `sso.getCredentialData`

**用途**：读取 SSO 凭证（内存解密）

```typescript
// 调用
const result = await api.runtime.gateway.call("sso.getCredentialData", {});

// 成功响应
{ success: true, data: { apiKey, llmName, llmUrl } }

// 失败响应
{ success: false, error: "SSO not ready" }
```

#### `sso.updateModelConfig`（仅联通）

**用途**：手动更新模型配置

**行为**：执行与插件加载相同的认证逻辑，成功则：

- 更新内存凭证（加密存储）
- 使用 `runtime.config.patch()` 写入 `openclaw.json`
- 配置 provider 为 `default-model`，自动追加 `/v1` 到 baseUrl

## 3. 可观测性

### 3.1 日志系统

- **输出**：`~/.openclaw/logs/sso.log`（独立于 OpenClaw 插件日志）
- **格式**：`[time] [pid:tid] [level] [file:func:line] message`
- **轮转**：
  - 单条日志 > 4096 字节 → 截断
  - 文件 > 8MB → 备份为 `.bak` 后重建
- **级别**：
  - **error**：严重故障（HMAC 失败、最终认证失败）
  - **warn**：可重试错误（网络错误、HTTP 502/503/504）
  - **info**：里程碑（SSO 成功、HTTP 成功摘要）
  - **debug**：杭研请求/响应明文细节（仅调试）

### 3.2 敏感数据处理

- **日志**：敏感字段仅输出 SHA-256 哈希前缀（`sensitiveHash()`）
- **IPC**：不传输 token/手机号明文
- **存储**：AES-256-GCM 加密（SDK 内置密钥）

### 3.3 HTTP 重试机制

**适用范围**：所有局点的 HTTP 请求

| 项 | 规则 |
|----|------|
| 单次超时 | `httpTimeoutMs`（默认 5000ms） |
| 重试次数 | `httpRetryCount`（默认 4 次，含第 1 次） |
| 重试间隔 | 300ms |
| **可重试** | 网络错误、HTTP 502/503/504 |
| **不可重试** | HMAC 签名失败、4xx、其他 5xx、业务 code 失败、字段缺失 |

### 3.4 埋点数据

**上报接口**：`reportTelemetryEventToGateway()` → `POST /api/telemetry/events`

**通用埋点字段**（所有局点）：

| 字段 | 类型 | 说明 |
|------|------|------|
| `event_type` | string | 固定为 `"sso"` |
| `sso_site` | string | 局点标识（`hangyan` / `unicom`） |
| `sso_api` | string | API 名称（`get-token` / `check-token` / `getUnionAiKey`） |
| `sso_ok` | boolean | 是否成功 |
| `sso_duration_ms` | number | 耗时（毫秒） |
| `sso_http_status` | number | HTTP 状态码（可选） |
| `sso_failure_reason` | string | 失败原因（可选） |

**杭研局点**：

- **getToken**：上报 `sso_api: "get-token"`
- **checkToken**：上报 `sso_api: "check-token"`

**联通局点**：

- **getUnionAiKey**：上报 `sso_api: "getUnionAiKey"`

### 3.5 错误类型

| 类型 | 含义 | 示例 |
|------|------|------|
| `SsoConfigError` | 配置缺失/非法 | 局点字段缺失、`site` 未知 |
| `SsoNetworkError` | 网络层失败 | 超时、DNS、`fetch` 抛错 |
| `SsoSystemError` | 本机系统错误 | 读 vmid 失败、HMAC 签名失败、写文件失败 |
| `SsoRuntimeError` | 远端业务失败 | 业务 code 非成功、字段缺失 |
| `SsoCryptoError` | 加解密/HMAC 失败 | AES、RSA、HMAC 失败 |

## 4. 流程图解

### 4.1 生成方式

使用 PlantUML 生成 PNG/SVG：

```bash
java -jar plantuml.jar -charset UTF-8 -tpng "*.puml"
```

### 4.2 PlantUML 源码

#### 4.2.1 SSO 启动与局点分派

```plantuml
@startuml co_claw_sso_01_startup
skinparam defaultFontName "Microsoft YaHei"
skinparam activity {
  BackgroundColor #E8F4FC
  DiamondBackgroundColor #FFF8E8
}
title SSO 启动流程：配置加载与局点分派

start
:Gateway 启动;
:OpenClaw 加载扩展\n含 SSO 插件（若打包已纳入）;
if (sso.json 文件存在？) then (否)
  #yellow:记录告警日志\n跳过 SSO 流程;
  :继续网关初始化;
  :Electron 侧正常进入主界面;
  stop
endif
:解析配置文件\nloadSsoJson;
if (可解析且\ntop 级 site 必选项满足？) then (否)
  #pink:抛出 SsoConfigError;
  :Electron 主界面展示错误;
  :停止 Gateway;
  :退出 Electron;
  stop
endif
:初始化日志系统\ninitLog(cfg.debug);
:清空凭证内存\nclearCredential;
:解析 vmid (platform/);
if (vmid 可用？) then (否)
  #pink:抛出 SsoSystemError;
  :Electron 主界面展示错误;
  :停止 Gateway;
  :退出 Electron;
  stop
endif
:按 site 分派 runSite;
if (site 为已注册局点？) then (是)
  :进入局点专属流程;
  stop
else (否)
  #pink:抛出 SsoConfigError\n(unknown site);
  :Electron 主界面展示错误;
  :停止 Gateway;
  :退出 Electron;
  stop
endif
@enduml
```

**说明**：

- **配置文件不存在**：仅记录告警日志，跳过 SSO 流程，继续初始化
- **配置文件无效/运行时错误**：展示错误 → 停止 Gateway → 退出 Electron

#### 4.2.2 杭研流程

```plantuml
@startuml co_claw_sso_02_hangyan
title SSO 局点流程：杭研（getToken → checkToken）

start
:杭研：校验 baseUrl 与四键、\ninitCredential();
if (四键与凭证就绪？) then (否)
  #pink:抛出 SsoConfigError;
  stop
endif
:构造 getToken 请求、HMAC 签名;
if (本地成功？) then (否)
  #pink:抛出 SsoSystemError\n(HMAC 签名失败);
  stop
endif
:POST getToken;
if (fetch 抛错或超时？) then (是)
  #pink:抛出 SsoNetworkError;
  stop
endif
if (HTTP status 2xx?) then (否)
  #pink:抛出 SsoRuntimeError\n(HTTP 失败);
  stop
endif
if (Body 合法 JSON 且\n业务 code="2000" 且含 token?) then (否)
  #pink:抛出 SsoRuntimeError\n(业务失败);
  stop
endif
:内存中 token 加密\naddCredentialData (AES-256-GCM);
:构造 checkToken 请求、HMAC 签名;
if (本地成功？) then (否)
  #pink:抛出 SsoSystemError\n(HMAC 签名失败);
  stop
endif
:POST checkToken;
if (fetch 抛错或超时？) then (是)
  #pink:抛出 SsoNetworkError;
  stop
endif
if (HTTP status 2xx?) then (否)
  #pink:抛出 SsoRuntimeError\n(HTTP 失败);
  stop
endif
if (Body 合法 JSON 且\n业务 code="2000" 且\n含 nickname/phone?) then (否)
  #pink:抛出 SsoRuntimeError\n(业务失败);
  stop
endif
:昵称、手机号经 AES-256 写入\naddCredentialData;
:返回成功;
stop
@enduml
```

**说明**：

- **两步 API**：getToken → checkToken
- **错误处理**：任何步骤失败都会抛出对应错误类型，最终退出
- **凭证存储**：token、nickname、phone 均加密存储在内存中

#### 4.2.3 联通流程

```plantuml
@startuml co_claw_sso_03_unicom
title SSO 局点流程：联通（getUnionAiKey）

start
:联通：校验 baseUrl 与 RSA 密钥;
if (RSA 密钥就绪？) then (否)
  #pink:抛出 SsoConfigError;
  stop
endif
:获取 vmid 和本机 IPv4 地址;
:构造 parameter: {resourceId=vmid, inIp="ip1,ip2,...", timestamp};
:RSA 公钥加密 parameter → Base64;
if (本地成功？) then (否)
  #pink:抛出 SsoCryptoError\n(RSA 加密失败);
  stop
endif
:POST getUnionAiKey\nBody: {"parameter": "<Base64>"};
if (fetch 抛错或超时？) then (是)
  #pink:抛出 SsoNetworkError;
  :继续运行\n记录日志;
  stop
endif
if (HTTP status 2xx?) then (否)
  #pink:抛出 SsoRuntimeError\n(HTTP 失败);
  :继续运行\n记录日志;
  stop
endif
if (Body 合法 JSON 且\n业务 code="200" 且 success=true\n且含 appKey/llmName/llmUrl?) then (否)
  #pink:抛出 SsoRuntimeError\n(业务失败);
  :继续运行\n记录日志;
  stop
endif
:RSA 私钥解密 appKey 得到 apiKey;
if (解密成功？) then (否)
  #pink:抛出 SsoCryptoError\n(RSA 解密失败);
  :继续运行\n记录日志;
  stop
endif
:调用 addCredentialData\n加密存储到内存 (apiKey, llmName, llmUrl);
:调用 runtime.config.patch()\n写入 openclaw.json;
:返回成功;
stop
@enduml
```

**说明**：

- **一步 API**：getUnionAiKey
- **失败策略**：API 调用失败时不退出，继续运行并记录日志
- **凭证存储**：内存加密 + 写入 `openclaw.json`

## 5. HTTP API 规格

### 5.1 杭研 API

详细规格见 **[HANGYAN_SSO_API.md](HANGYAN_SSO_API.md)**

#### 5.1.1 getToken

- **方法**：`POST /terminal/token/sso/getToken/v1`
- **HMAC 签名 Path**：`/token/sso/getToken/v1`（无 `/terminal` 前缀）
- **请求体**：`{"type":"6","vmid":"<vmid>"}`
- **成功**：`code: "2000"`，取 `data.token`

#### 5.1.2 checkToken

- **方法**：`POST /cube/external/checkToken`
- **HMAC 签名 Path**：`/external/checkToken`（无 `/cube` 前缀）
- **请求体**：`{"token":"<token>"}`
- **成功**：`code: "2000"`，取 `data.nickname`、`data.phone`

### 5.2 联通 API

详细规格见 **[UNICOM_SSO_API.md](UNICOM_SSO_API.md)**

#### getUnionAiKey

- **方法**：`POST /openapi/user/getUnionAiKeyByResourceId`
- **请求体**：`{"parameter": "<RSA 加密的 Base64 字符串>"}`
- **Headers**：
  - `Content-Type: application/json`
  - `Device-Type: pc | phone`（自动判断）
- **加密 parameter**：`{ "resourceId": "<vmid>", "inIp": "<IPv4 逗号分隔>", "timestamp": 1234567890123 }`
  - `resourceId`：使用 vmid（从系统自动获取）
  - `inIp`：本机所有 IPv4 地址（逗号分隔，如 `"192.168.1.100,10.0.0.50"`）
- **成功**：`code: "200"` 且 `success: true`
- **响应**：`data.appKey`（RSA 加密）、`data.llmName`、`data.llmUrl`
- **解密**：RSA 私钥解密 `appKey` → `apiKey` 明文
- **配置写入**：使用 `runtime.config.patch()` 写入 `openclaw.json`
