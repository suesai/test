# 联通 AI Key API 接口文档

本文档详细描述联通云桌面 AI 能力接入的 `getUnionAiKeyByResourceId` HTTP API 接口，用于根据资源 ID 获取 AI 模型配置（包括 API Key、模型名称、模型 URL）。

## 目录

- [1. getUnionAiKeyByResourceId 接口](#1-getunionaikeybyresourceid-接口)
  - [1.1 接口概述](#11-接口概述)
  - [1.2 请求协议](#12-请求协议)
  - [1.3 请求路径](#13-请求路径)
  - [1.4 请求头](#14-请求头)
  - [1.5 请求体](#15-请求体)
  - [1.6 加密算法](#16-加密算法)
  - [1.7 响应格式](#17-响应格式)
  - [1.8 成功判定](#18-成功判定)
  - [1.9 解密算法](#19-解密算法)
  - [1.10 Python 代码示例](#110-python-代码示例)
- [2. 错误处理](#2-错误处理)

---

## 1. getUnionAiKeyByResourceId 接口

### 1.1 接口概述

**功能**：根据资源 ID 获取 AI 模型配置（API Key、模型名称、模型 URL）  
**调用时机**：云桌面 AI 能力初始化或需要刷新 AI 配置时  
**输入**：
- `resourceId`：资源 ID（由联通分配）
- `inIp`：内网 IP 地址
- `timestamp`：毫秒时间戳

**输出**：
- `apiKey`：解密后的 API Key（明文）
- `llmName`：大模型名称
- `llmUrl`：大模型服务 URL

**⚠️ 重要说明**：

- 请求参数使用 **RSA 公钥加密**（联通提供公钥）
- 响应中的 `appKey` 字段使用 **RSA 私钥解密**（调用方自备私钥）
- 加密/解密均使用 **RSA_PKCS1_PADDING** 填充模式

### 1.2 请求协议

- **方法**：`POST`
- **协议**：HTTPS（推荐）或 HTTP
- **Content-Type**：`application/json`

### 1.3 请求路径

- **实际请求路径**：`/openapi/user/getUnionAiKeyByResourceId`

**完整 URL 示例**：

```
https://<联通云桌面 API 域名>/openapi/user/getUnionAiKeyByResourceId
```

### 1.4 请求头

| 字段名 | 必填 | 示例值 | 说明 |
|--------|------|--------|------|
| `Content-Type` | 是 | `application/json` | 内容类型，固定为 `application/json` |
| `Device-Type` | 否 | `pc` | 设备类型，可选值：`pc`、`phone` |

**⚠️ 注意事项**：

- `Device-Type` 为可选字段，用于区分设备类型
- 其他标准 HTTP 头（如 `User-Agent`）可按需添加

### 1.5 请求体

#### 1.5.1 外层 JSON 结构

```json
{
  "parameter": "<Base64 编码的加密参数字符串>"
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `parameter` | string | RSA 加密后的 Base64 字符串（见 1.6 节） |

#### 1.5.2 内层明文参数（加密前）

在 RSA 加密之前，需要构造如下 JSON 对象：

```json
{
  "resourceId": "res-12345",
  "inIp": "192.168.1.100",
  "timestamp": 1704067200000
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `resourceId` | string | 资源 ID（由联通分配） |
| `inIp` | string | 内网 IP 地址 |
| `timestamp` | number | 毫秒时间戳（当前时间） |

#### 1.5.3 加密流程

1. 构造内层 JSON 对象（包含 `resourceId`、`inIp`、`timestamp`）
2. 序列化为 UTF-8 JSON 字符串
3. 使用联通提供的 **RSA 公钥** 进行加密（PKCS1 填充）
4. 将加密后的二进制数据转换为 Base64 字符串
5. 将 Base64 字符串作为外层 `parameter` 字段的值

### 1.6 加密算法

#### 1.6.1 RSA 公钥信息

**联通提供的公钥（Base64 编码）**：

```
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIPRSOEVyZFWqd6cjh4qIgYz/tVrdg0TH2XeAuBLIzjzdxNKOevUJKuSiiQtWeGQI1hxmIRtGryFT7/2JU+HLkcklkvL7Wt+8w/ilmuvmFQrHaMd0uBGrk3U8u6s8owceFRIpjYeQt7Wp12wqkWzavHVIwWxyv7ymiaTlGdU00UwIDAQAB
```

**转换为 PEM 格式**：

```pem
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIPRSOEVyZFWqd6cjh4qIgYz/t
Vrdg0TH2XeAuBLIzjzdxNKOevUJKuSiiQtWeGQI1hxmIRtGryFT7/2JU+HLkcklk
vL7Wt+8w/ilmuvmFQrHaMd0uBGrk3U8u6s8owceFRIpjYeQt7Wp12wqkWzavHVIw
Wxyv7ymiaTlGdU00UwIDAQAB
-----END PUBLIC KEY-----
```

#### 1.6.2 加密步骤（Python 示例）

```python
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
import base64
import json

# 公钥 PEM
public_key_pem = """-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIPRSOEVyZFWqd6cjh4qIgYz/t
Vrdg0TH2XeAuBLIzjzdxNKOevUJKuSiiQtWeGQI1hxmIRtGryFT7/2JU+HLkcklk
vL7Wt+8w/ilmuvmFQrHaMd0uBGrk3U8u6s8owceFRIpjYeQt7Wp12wqkWzavHVIw
Wxyv7ymiaTlGdU00UwIDAQAB
-----END PUBLIC KEY-----"""

# 加载公钥
public_key = serialization.load_pem_public_key(public_key_pem.encode('utf-8'))

# 构造内层参数
inner_params = {
    "resourceId": "res-12345",
    "inIp": "192.168.1.100",
    "timestamp": 1704067200000
}

# 序列化为 JSON 字符串
payload_json = json.dumps(inner_params)

# RSA 加密（PKCS1 填充）
encrypted_bytes = public_key.encrypt(
    payload_json.encode('utf-8'),
    padding.PKCS1v15()
)

# Base64 编码
parameter_base64 = base64.b64encode(encrypted_bytes).decode('utf-8')
```

**⚠️ 注意事项**：

- 必须使用 **PKCS1v15** 填充（即 `RSA_PKCS1_PADDING`）
- 加密前的 JSON 字符串必须是 UTF-8 编码
- 加密后的二进制数据必须转换为 Base64 字符串

### 1.7 响应格式

#### 1.7.1 成功响应示例

```json
{
  "code": "200",
  "msg": "success",
  "success": true,
  "data": {
    "appKey": "Zm9vYmFyMTIzNDU2Nzg5MA==",
    "appVersion": "1.0.0",
    "status": "active",
    "llmName": "qwen-max",
    "llmUrl": "https://dashscope.aliyuncs.com/compatible-mode/v1"
  }
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | string | 业务状态码，成功时为 `"200"` |
| `msg` | string | 状态描述，成功时为 `"success"` |
| `success` | boolean | 成功标志，成功时为 `true` |
| `data` | object | 响应数据对象 |
| `data.appKey` | string | **加密后的** API Key（Base64 字符串，需要 RSA 私钥解密） |
| `data.appVersion` | string | 应用版本 |
| `data.status` | string | 资源状态（如 `active`） |
| `data.llmName` | string | 大模型名称（如 `qwen-max`） |
| `data.llmUrl` | string | 大模型服务 URL |

#### 1.7.2 失败响应示例

```json
{
  "code": "400",
  "msg": "Invalid resourceId",
  "success": false
}
```

#### 1.7.3 响应字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | string | 业务状态码 |
| `msg` | string | 状态描述或错误信息 |
| `success` | boolean | 成功标志（`true` / `false`） |
| `data` | object | 响应数据（成功时存在） |

### 1.8 成功判定

**成功条件**（同时满足）：

1. HTTP 状态码为 `2xx`（通常是 200）
2. 响应体 JSON 的 `code` 字段等于 `"200"`
3. `success` 字段等于 `true`
4. `data` 字段是对象（不是数组或字符串）
5. `data.llmName`、`data.llmUrl`、`data.appKey` 均为非空字符串

**⚠️ 注意事项**：

- 即使 `code` 和 `success` 表示成功，`data.appKey` 仍然是**加密后的密文**
- 必须使用 RSA 私钥解密 `appKey` 才能得到真正的 API Key

### 1.9 解密算法

#### 1.9.1 RSA 私钥要求

**调用方需要自备 RSA 私钥**，私钥格式为 PEM：

```pem
-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA...（你的私钥内容）
-----END RSA PRIVATE KEY-----
```

**⚠️ 重要说明**：

- 私钥由**调用方自行生成和保管**
- 联通方面使用对应的公钥加密 `appKey`
- 私钥必须安全存储，不能泄露

#### 1.9.2 解密步骤（Python 示例）

```python
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
import base64

# 私钥 PEM（从安全配置中读取）
private_key_pem = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA...（你的私钥内容）
-----END RSA PRIVATE KEY-----"""

# 加载私钥
private_key = serialization.load_pem_private_key(
    private_key_pem.encode('utf-8'),
    password=None  # 如果私钥有密码，在此传入
)

# 加密的 appKey（从响应中获取）
encrypted_appkey_base64 = "Zm9vYmFyMTIzNDU2Nzg5MA=="

# Base64 解码
encrypted_bytes = base64.b64decode(encrypted_appkey_base64)

# RSA 解密（PKCS1 填充）
decrypted_bytes = private_key.decrypt(
    encrypted_bytes,
    padding.PKCS1v15()
)

# 转换为 UTF-8 字符串（即 API Key 明文）
api_key = decrypted_bytes.decode('utf-8').strip()
```

**⚠️ 注意事项**：

- 解密必须使用 **PKCS1v15** 填充（与加密端一致）
- 解密后的字符串需要去除首尾空白字符
- 解密后的 `apiKey` 是明文，需要安全存储和使用

### 1.10 Python 代码示例

```python
#!/usr/bin/env python3
"""
联通 AI Key API Python 实现示例
getUnionAiKeyByResourceId 接口调用
"""

import base64
import json
import requests
from typing import Optional
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding


# 联通提供的 RSA 公钥（PEM 格式）
UNICOM_PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIPRSOEVyZFWqd6cjh4qIgYz/t
Vrdg0TH2XeAuBLIzjzdxNKOevUJKuSiiQtWeGQI1hxmIRtGryFT7/2JU+HLkcklk
vL7Wt+8w/ilmuvmFQrHaMd0uBGrk3U8u6s8owceFRIpjYeQt7Wp12wqkWzavHVIw
Wxyv7ymiaTlGdU00UwIDAQAB
-----END PUBLIC KEY-----"""


def encrypt_request_params(
    resource_id: str,
    in_ip: str,
    timestamp: int
) -> str:
    """
    加密请求参数
    
    Args:
        resource_id: 资源 ID
        in_ip: 内网 IP
        timestamp: 毫秒时间戳
    
    Returns:
        Base64 编码的加密参数字符串
    """
    # 构造内层参数
    inner_params = {
        "resourceId": resource_id,
        "inIp": in_ip,
        "timestamp": timestamp
    }
    
    # 序列化为 JSON 字符串
    payload_json = json.dumps(inner_params)
    
    # 加载公钥
    public_key = serialization.load_pem_public_key(UNICOM_PUBLIC_KEY_PEM.encode('utf-8'))
    
    # RSA 加密（PKCS1 填充）
    encrypted_bytes = public_key.encrypt(
        payload_json.encode('utf-8'),
        padding.PKCS1v15()
    )
    
    # Base64 编码
    return base64.b64encode(encrypted_bytes).decode('utf-8')


def decrypt_app_key(
    encrypted_base64: str,
    private_key_pem: str
) -> str:
    """
    解密 appKey
    
    Args:
        encrypted_base64: 加密的 Base64 字符串
        private_key_pem: RSA 私钥（PEM 格式）
    
    Returns:
        解密后的 API Key（明文）
    """
    # 加载私钥
    private_key = serialization.load_pem_private_key(
        private_key_pem.encode('utf-8'),
        password=None
    )
    
    # Base64 解码
    encrypted_bytes = base64.b64decode(encrypted_base64)
    
    # RSA 解密（PKCS1 填充）
    decrypted_bytes = private_key.decrypt(
        encrypted_bytes,
        padding.PKCS1v15()
    )
    
    # 转换为 UTF-8 字符串
    return decrypted_bytes.decode('utf-8').strip()


def get_union_ai_key_by_resource_id(
    base_url: str,
    resource_id: str,
    in_ip: str,
    private_key_pem: str,
    device_type: Optional[str] = None,
    http_timeout_ms: int = 10000
) -> Optional[dict]:
    """
    调用联通 getUnionAiKeyByResourceId 接口获取 AI 配置
    
    Args:
        base_url: 基础 URL，如 https://api.example.com
        resource_id: 资源 ID
        in_ip: 内网 IP
        private_key_pem: RSA 私钥（PEM 格式）
        device_type: 设备类型（可选，'pc' 或 'phone'）
        http_timeout_ms: HTTP 超时时间（毫秒）
    
    Returns:
        成功时返回 dict：{apiKey, llmName, llmUrl}
        失败时返回 None
    """
    import time
    
    # 请求路径
    request_path = "/openapi/user/getUnionAiKeyByResourceId"
    
    # 生成时间戳
    timestamp = int(time.time() * 1000)
    
    # 加密请求参数
    parameter = encrypt_request_params(resource_id, in_ip, timestamp)
    
    # 构造请求体
    request_body = json.dumps({"parameter": parameter})
    
    # 构造请求头
    request_headers = {
        "Content-Type": "application/json",
    }
    if device_type:
        request_headers["Device-Type"] = device_type
    
    # 发送请求
    url = f"{base_url.rstrip('/')}{request_path}"
    try:
        response = requests.post(
            url,
            headers=request_headers,
            data=request_body,
            timeout=http_timeout_ms / 1000.0
        )
        
        # 检查 HTTP 状态码
        if response.status_code != 200:
            print(f"HTTP 错误：{response.status_code}")
            return None
        
        # 解析响应
        resp_json = response.json()
        code = resp_json.get("code")
        success = resp_json.get("success")
        
        # 检查业务状态码
        if code != "200" or success is not True:
            msg = resp_json.get("msg", "")
            print(f"业务错误：code={code}, success={success}, msg={msg}")
            return None
        
        # 提取 data 字段
        data = resp_json.get("data")
        if not data or not isinstance(data, dict):
            print("data 字段缺失或不是对象")
            return None
        
        llm_name = data.get("llmName", "").strip()
        llm_url = data.get("llmUrl", "").strip()
        encrypted_app_key = data.get("appKey", "").strip()
        
        # 检查必填字段
        if not llm_name or not llm_url or not encrypted_app_key:
            print("响应缺少 llmName/llmUrl/appKey")
            return None
        
        # 解密 appKey
        api_key = decrypt_app_key(encrypted_app_key, private_key_pem)
        if not api_key:
            print("解密后的 apiKey 为空")
            return None
        
        return {
            "apiKey": api_key,
            "llmName": llm_name,
            "llmUrl": llm_url
        }
        
    except requests.exceptions.RequestException as e:
        print(f"网络错误：{e}")
        return None
    except json.JSONDecodeError as e:
        print(f"JSON 解析错误：{e}")
        return None
    except Exception as e:
        print(f"其他错误：{e}")
        return None


if __name__ == "__main__":
    # 配置参数
    BASE_URL = "https://api.example.com"
    RESOURCE_ID = "your-resource-id-here"
    IN_IP = "192.168.1.100"
    
    # 私钥 PEM（从安全配置中读取，不要硬编码在代码中）
    PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA...（你的私钥内容）
-----END RSA PRIVATE KEY-----"""
    
    # 调用接口
    result = get_union_ai_key_by_resource_id(
        base_url=BASE_URL,
        resource_id=RESOURCE_ID,
        in_ip=IN_IP,
        private_key_pem=PRIVATE_KEY_PEM
    )
    
    if result:
        print(f"获取 AI 配置成功：")
        print(f"  - llmName: {result['llmName']}")
        print(f"  - llmUrl: {result['llmUrl']}")
        print(f"  - apiKey: {result['apiKey'][:20]}...")
    else:
        print("获取 AI 配置失败")
```

---

## 2. 错误处理

### 2.1 错误类型分类

| 错误类型 | 说明 | 处理方式 |
|----------|------|----------|
| **网络错误** | 超时、DNS 解析失败、连接拒绝等 | 可重试 |
| **HTTP 错误** | HTTP 状态码非 2xx | 根据状态码决定是否重试（502/503/504 可重试） |
| **业务错误** | 响应中 `code` 非 `"200"` 或 `success` 非 `true` | 不可重试，需检查请求参数 |
| **数据错误** | 响应 JSON 格式错误、字段缺失 | 不可重试，需检查接口契约 |
| **解密失败** | RSA 私钥解密 `appKey` 失败 | 检查私钥是否正确、是否与加密公钥配对 |

### 2.2 常见业务错误码

| 错误码 | 说明 |
|--------|------|
| `200` | 成功 |
| `400` | 请求参数错误（如 resourceId 无效） |
| `401` | 认证失败 |
| `403` | 权限不足 |
| `404` | 资源不存在 |
| `500` | 服务器内部错误 |

### 2.3 解密失败常见原因

| 原因 | 说明 | 解决方式 |
|------|------|----------|
| **私钥不匹配** | 使用的私钥与加密公钥不配对 | 确认私钥与公钥是一对 |
| **填充模式错误** | 解密时使用了错误的填充模式 | 必须使用 `PKCS1v15`（即 `RSA_PKCS1_PADDING`） |
| **Base64 解码失败** | `appKey` 字段不是合法的 Base64 | 检查响应数据是否被篡改 |
| **UTF-8 解码失败** | 解密后的二进制数据不是合法的 UTF-8 | 检查解密逻辑或联系联通技术支持 |

---

**参考文档**：

- 《云电脑接口 - 获取联通 AI KEY 接口.docx》
