# 杭研 SSO API 接口文档

本文档详细描述杭研 SSO（单点登录）系统的两个核心 HTTP API 接口，用于获取 token 和校验 token 并获取用户信息。

## 目录

- [1. getToken 接口](#1-gettoken-接口)
  - [1.1 接口概述](#11-接口概述)
  - [1.2 请求协议](#12-请求协议)
  - [1.3 请求路径](#13-请求路径)
  - [1.4 请求头](#14-请求头)
  - [1.5 请求体](#15-请求体)
  - [1.6 签名算法](#16-签名算法)
  - [1.7 响应格式](#17-响应格式)
  - [1.8 成功判定](#18-成功判定)
  - [1.9 Python 代码示例](#19-python-代码示例)
- [2. checkToken 接口](#2-checktoken-接口)
  - [2.1 接口概述](#21-接口概述)
  - [2.2 请求协议](#22-请求协议)
  - [2.3 请求路径](#23-请求路径)
  - [2.4 请求头](#24-请求头)
  - [2.5 请求体](#25-请求体)
  - [2.6 签名算法](#26-签名算法)
  - [2.7 响应格式](#27-响应格式)
  - [2.8 成功判定](#28-成功判定)
  - [2.9 Python 代码示例](#29-python-代码示例)
- [3. 错误处理](#3-错误处理)

---

## 1. getToken 接口

### 1.1 接口概述

**功能**：获取 SSO 访问 token  
**调用时机**：SSO 登录流程的第一步  
**输入**：

- `vmid`：虚拟机 ID
- `type`：接入方类型（杭研局点固定为 **6**）

**输出**：token（用于后续 checkToken 调用）

**⚠️ 重要说明**：

- getToken 和 checkToken 使用**不同的** `appKey` 和 `appSecret`（均由杭研提供）：
  - getToken 使用 `getTokenAppKey` 和 `getTokenAppSecret`（HMAC 密钥为 hex 解码）
  - checkToken 使用 `checkTokenAppKey` 和 `checkTokenAppSecret`（HMAC 密钥为 UTF-8 字符串）

### 1.2 请求协议

- **方法**：`POST`
- **协议**：HTTPS（推荐）或 HTTP
- **Content-Type**：`application/json`

### 1.3 请求路径

- **实际请求路径**：`/terminal/token/sso/getToken/v1`
- **签名使用路径**：`/token/sso/getToken/v1`（⚠️ **无** `/terminal` 前缀）

**完整 URL 示例**：

```
https://soho.komect.com/terminal/token/sso/getToken/v1
```

### 1.4 请求头

#### 1.4.1 参与签名的请求头（按字典序排序）

| 字段名 | 必填 | 示例值 | 说明 |
| :--- | :--- | :--- | :--- |
| `X-SOHO-AppKey` | 是 | `********************************` | 应用标识（由杭研提供） |
| `X-SOHO-AppType` | 是 | `Linux\|5.15.0\|Linux\|0\|1\|ABC123\|` | **应用类型**，格式：`{OS 名称}\|{OS 版本}\|{OS 名称}\|{网络状态}\|{运营商}\|{序列号}\|`<br>• **OS 名称**：操作系统名称（Linux、Darwin、Windows）<br>• **OS 版本**：操作系统版本号（如 `5.15.0`）<br>• **OS 名称**：重复一次 OS 名称<br>• **网络状态**：`-1`（没有网络）、`0`（有线网络）、`1`（WIFI 网络）、`2`（2G 网络）、`3`（3G 网络）、`4`（4G 网络）、`5`（5G 网络）<br>• **运营商**：`-1`（无）、`1`（移动）、`2`（联通）、`3`（电信）<br>• **序列号**：主机硬件序列号<br>• **末尾**：必须以 `\|` 结尾 |
| `X-SOHO-ClientVersion` | 是 | `1.0.0` | 客户端版本，固定为 `1.0.0` |
| `X-SOHO-DeviceId` | 是 | `vmid-12345` | 设备 ID，即 vmid |
| `X-SOHO-RomVersion` | 是 | `Linux-5.15.0-generic` | ROM 版本，格式：`{OS 名称}-{OS 版本}-{OS Release}` |
| `X-SOHO-Timestamp` | 是 | `1704067200000` | 毫秒时间戳（当前时间） |
| `X-SOHO-UserId` | 是 | `-1` | 用户 ID，固定为 `-1`（表示未登录/匿名） |
| `X-SOHO-Uuid` | 是 | `550e8400e29b41d4a716446655440000` | UUID（**无连字符**，32 位十六进制），每次请求重新生成 |
| `X-SOHO-VersionNum` | 是 | `1` | 版本号，固定为 `1` |

**⚠️ 注意事项**：

- 所有参与签名的请求头按**字典序**（字母顺序）排列
- `X-SOHO-AppType` 的格式必须严格遵循 `{OS 名称}|{OS 版本}|{OS 名称}|{网络状态}|{运营商}|{序列号}|`，**末尾必须有 `|`**
- `X-SOHO-UserId` 固定为 `-1`，表示 SSO 认证前的匿名状态
- `X-SOHO-Uuid` 每次请求都必须重新生成，用于防重放攻击
- `X-SOHO-Signature`、`User-Agent`、`X-SOHO-SohoToken`、`Content-Type` **不参与**签名计算

#### 1.4.2 不参与签名的请求头

| 字段名 | 必填 | 示例值 | 说明 |
| :--- | :--- | :--- | :--- |
| `X-SOHO-Signature` | 是 | `a1b2c3d4e5f6...` | HMAC-SHA256 签名（小写 hex），由签名算法计算得出 |
| `X-SOHO-SohoToken` | 是 | ``（空字符串） | Soho token，请求时必须为空串（认证前无 token） |
| `User-Agent` | 是 | `jtydn-1.0.0` | 用户代理，固定为 `jtydn-1.0.0` |
| `Content-Type` | 是 | `application/json` | 内容类型，固定为 `application/json` |

**⚠️ 注意事项**：

- `X-SOHO-Signature`、`User-Agent`、`X-SOHO-SohoToken`、`Content-Type` **不参与**签名计算
- 签名字符串中只包含 1.4.1 节中列出的 9 个字段 + `body` 字段

### 1.5 请求体

#### 1.5.1 内层 JSON 结构

```json
{
  "type": 6,
  "data": "{\"vmid\":\"vmid-12345\"}"
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `type` | number | **接入方类型**，杭研局点固定为 **6** |
| `data` | string | 内层 JSON 的字符串形式（注意：是 JSON 字符串，不是对象） |

#### 1.5.2 内层 `data` 字段结构

内层 `data` 字段是一个 JSON 字符串，解码后为：

```json
{
  "vmid": "vmid-12345"
}
```

#### 1.5.3 最终 HTTP 请求体

将内层 JSON 进行 Base64 编码后，作为外层 `data` 字段：

```json
{
  "data": "eyJ0eXBlIjo2LCJkYXRhIjoie1widm1pZFwiOlwidm1pZC0xMjM0NVwifSJ9"
}
```

**构造步骤**：

1. 构造内层 JSON 对象：`{ "type": 6, "data": "{\"vmid\":\"vmid-12345\"}" }`
2. 序列化为 JSON 字符串：`"{\"type\":6,\"data\":\"{\\\"vmid\\\":\\\"vmid-12345\\\"}\"}"`
3. 对步骤 2 的字符串进行 Base64 编码：`"eyJ0eXBlIjo2LCJkYXRhIjoie1widm1pZFwiOlwidm1pZC0xMjM0NVwifSJ9"`
4. 构造最终请求体：`{ "data": "<步骤 3 的 Base64 字符串>" }`
5. 将步骤 4 的对象序列化为 JSON 字符串作为 HTTP Body

### 1.6 签名算法

#### 1.6.1 签名字符串格式

```
POST&/token/sso/getToken/v1&X-SOHO-AppKey=<appKey>&X-SOHO-AppType=<appType>&...&X-SOHO-VersionNum=1&body=<bodyData>
```

**构造规则**：

1. 固定前缀：`POST&` + 签名路径（`/token/sso/getToken/v1`）
2. 按**字典序**（字母顺序）排列所有参与签名的请求头字段
3. 每个字段格式：`&字段名=字段值`
4. 最后添加：`&body=<bodyData>`，其中 `bodyData` 是步骤 1.5.2 中内层 JSON 的 Base64 编码字符串

**⚠️ 注意事项**：

- `X-SOHO-Signature` 和 `User-Agent` **不参与**签名
- `X-SOHO-SohoToken` 在 HTTP 头中传空串，**不参与**签名
- `body` 字段的值是内层 JSON 的 Base64 编码，不是最终 HTTP Body 的 Base64

#### 1.6.2 HMAC 签名

- **算法**：HMAC-SHA256
- **密钥**：`getTokenAppSecret`（十六进制字符串）需要**按字节解码**为 Buffer
- **输出**：小写十六进制字符串

**示例**：

```python
import hmac
import hashlib

# getTokenAppSecret 是十六进制字符串，需要解码为字节
getTokenAppSecret_hex = "********************************"
key_bytes = bytes.fromhex(getTokenAppSecret_hex)

# 签名字符串
sign_payload = "POST&/token/sso/getToken/v1&X-SOHO-AppKey=...&body=..."

# 计算 HMAC-SHA256
signature = hmac.new(key_bytes, sign_payload.encode('utf-8'), hashlib.sha256).hexdigest().lower()
```

### 1.7 响应格式

#### 1.7.1 成功响应示例

```json
{
  "code": "2000",
  "msg": "success",
  "data": {
    "token": "********************************"
  }
}
```

**⚠️ 重要说明**：

- `data` 字段是一个 **JSON 对象**，不是字符串
- `data` 对象中包含 `token` 字段，值为 JWT 格式的 token 字符串

#### 1.7.2 失败响应示例

```json
{
  "code": "5000",
  "msg": "Invalid vmid",
  "businessCode": "INVALID_VMID",
  "errMsg": "The provided vmid is invalid"
}
```

#### 1.7.3 响应字段说明

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `code` | string | 业务状态码，成功时为 `"2000"` |
| `msg` | string | 状态描述，成功时为 `"success"` |
| `data` | object | 响应数据，**JSON 对象**，包含 `token` 字段 |
| `data.token` | string | JWT 格式的 token 字符串 |
| `businessCode` | string | 业务错误码（失败时） |
| `errMsg` | string | 错误详情（失败时） |

**⚠️ 注意事项**：

- `data` 字段**始终是 JSON 对象**，不是字符串
- 如果响应中 `data` 是字符串，说明响应格式异常

### 1.8 成功判定

**成功条件**（同时满足）：

1. HTTP 状态码为 `2xx`（通常是 200）
2. 响应体 JSON 的 `code` 字段等于 `"2000"`
3. `data` 字段是 JSON 对象（不是数组或字符串）
4. `data.token` 字段是非空字符串

**token 提取规则**：

- `data` 应该是对象，直接读取 `data.token`
- ⚠️ 如果 `data` 是字符串，说明响应格式异常，应报错

### 1.9 Python 代码示例

```python
#!/usr/bin/env python3
"""
杭研 SSO getToken 接口 Python 实现示例
"""

import base64
import hashlib
import hmac
import json
import time
import uuid
import platform
import requests
from typing import Optional


def generate_uuid_no_dash() -> str:
    """生成无连字符的 UUID（32 位十六进制）"""
    return uuid.uuid4().hex


def get_os_info() -> tuple[str, str, str]:
    """获取操作系统信息"""
    system = platform.system()  # Linux, Darwin, Windows
    release = platform.release()  # 版本号
    version = platform.version()  # 详细版本
    return system, release, version


def get_machine_serial() -> str:
    """获取机器序列号（简化版，实际可能需要更复杂的逻辑）"""
    # 这里简化处理，实际应该读取硬件序列号
    return "UNKNOWN_SERIAL"


def build_app_type(os_name: str, os_version: str, serial: str) -> str:
    """构建 X-SOHO-AppType 字段值"""
    network_status = "0"
    carrier = "1"
    return f"{os_name}|{os_version}|{os_name}|{network_status}|{carrier}|{serial}|"


def build_rom_version(os_name: str, os_version: str, os_release: str) -> str:
    """构建 X-SOHO-RomVersion 字段值"""
    return f"{os_name}-{os_version}-{os_release}"


def hmac_sha256_hex(key: bytes, message: str) -> str:
    """计算 HMAC-SHA256 并返回小写 hex 字符串"""
    return hmac.new(key, message.encode('utf-8'), hashlib.sha256).hexdigest().lower()


def build_sign_payload(
    sign_path: str,
    headers: dict[str, str | int],
    body_data: str
) -> str:
    """构建签名字符串"""
    # 按字典序排序请求头字段
    sorted_keys = sorted(headers.keys())
    
    # 构建签名字符串
    payload = f"POST&{sign_path}"
    for key in sorted_keys:
        if key in ("X-SOHO-Signature", "User-Agent"):
            continue
        payload += f"&{key}={headers[key]}"
    payload += f"&body={body_data}"
    
    return payload


def hangyan_get_token(
    base_url: str,
    vmid: str,
    getTokenAppKey: str,
    getTokenAppSecret: str,
    http_timeout_ms: int = 4000
) -> Optional[str]:
    """
    调用杭研 getToken 接口获取 token
    
    Args:
        base_url: 基础 URL，如 https://soho.komect.com
        vmid: 虚拟机 ID
        getTokenAppKey: 应用标识（从配置文件 `getTokenAppKey` 获取）
        getTokenAppSecret: HMAC 密钥（十六进制字符串，从配置文件 `getTokenAppSecret` 获取）
        http_timeout_ms: HTTP 超时时间（毫秒）
    
    Returns:
        成功时返回 token，失败时返回 None
    
    ⚠️ 注意：
        getToken 和 checkToken 使用不同的 appKey 和 appSecret
    """
    # 请求路径
    request_path = "/terminal/token/sso/getToken/v1"
    sign_path = "/token/sso/getToken/v1"  # 签名用，无 /terminal 前缀
    
    # 生成请求参数
    uuid_val = generate_uuid_no_dash()
    timestamp = int(time.time() * 1000)
    
    # 获取系统信息
    os_name, os_release, os_version = get_os_info()
    serial = get_machine_serial()
    app_type = build_app_type(os_name, os_release, serial)
    rom_version = build_rom_version(os_name, os_release, os_version)
    
    # 构造内层 JSON
    inner_data = json.dumps({"vmid": vmid})
    inner_json = json.dumps({
        "type": 6,  # 接入方类型，杭研局点为 6
        "data": inner_data
    })
    
    # Base64 编码内层 JSON
    body_data = base64.b64encode(inner_json.encode('utf-8')).decode('utf-8')
    
    # 最终请求体
    final_body = json.dumps({"data": body_data})
    
    # 构建参与签名的请求头
    sign_headers = {
        "X-SOHO-AppKey": getTokenAppKey,
        "X-SOHO-AppType": app_type,
        "X-SOHO-ClientVersion": "1.0.0",
        "X-SOHO-DeviceId": vmid,
        "X-SOHO-RomVersion": rom_version,
        "X-SOHO-Timestamp": str(timestamp),
        "X-SOHO-UserId": "-1",
        "X-SOHO-Uuid": uuid_val,
        "X-SOHO-VersionNum": 1,
    }
    
    # 构建签名字符串
    sign_payload = build_sign_payload(sign_path, sign_headers, body_data)
    
    # 计算签名（getTokenAppSecret 是 hex 字符串，需要解码为字节）
    key_bytes = bytes.fromhex(getTokenAppSecret)
    signature = hmac_sha256_hex(key_bytes, sign_payload)
    
    # 构建最终请求头
    request_headers = {
        **{k: str(v) for k, v in sign_headers.items()},
        "X-SOHO-Signature": signature,
        "X-SOHO-SohoToken": "",
        "User-Agent": "jtydn-1.0.0",
        "Content-Type": "application/json",
    }
    
    # 发送请求
    url = f"{base_url}{request_path}"
    try:
        response = requests.post(
            url,
            headers=request_headers,
            data=final_body,
            timeout=http_timeout_ms / 1000.0
        )
        
        # 检查 HTTP 状态码
        if response.status_code != 200:
            print(f"HTTP 错误：{response.status_code}")
            return None
        
        # 解析响应
        resp_json = response.json()
        code = resp_json.get("code")
        
        # 检查业务状态码
        if code != "2000":
            msg = resp_json.get("msg", "")
            print(f"业务错误：code={code}, msg={msg}")
            return None
        
        # 提取 token（data 应该是对象，不是字符串）
        data = resp_json.get("data")
        if not data or not isinstance(data, dict):
            print("data 字段不是 JSON 对象")
            return None
        
        token = data.get("token")
        if not token or not isinstance(token, str) or not token.strip():
            print("token 缺失或无效")
            return None
        
        return token.strip()
        
    except requests.exceptions.RequestException as e:
        print(f"网络错误：{e}")
        return None
    except json.JSONDecodeError as e:
        print(f"JSON 解析错误：{e}")
        return None


if __name__ == "__main__":
    # 配置参数
    BASE_URL = "https://soho.komect.com"
    VMID = "your-vmid-here"
    GET_TOKEN_APP_KEY = "********************************"
    GET_TOKEN_APP_SECRET = "********************************"
    
    # 调用接口
    token = hangyan_get_token(
        base_url=BASE_URL,
        vmid=VMID,
        getTokenAppKey=GET_TOKEN_APP_KEY,
        getTokenAppSecret=GET_TOKEN_APP_SECRET
    )
    
    if token:
        print(f"获取 token 成功：{token[:20]}...")
    else:
        print("获取 token 失败")
```

---

## 2. checkToken 接口

### 2.1 接口概述

**功能**：校验 token 并获取用户信息（昵称、手机号）  
**调用时机**：SSO 登录流程的第二步，在成功调用 getToken 之后  
**输入**：token（从 getToken 接口获取）  
**输出**：nickname（昵称）、phone（手机号）

**⚠️ 重要说明**：

- getToken 和 checkToken 使用**不同的** `appKey` 和 `appSecret`（均由杭研提供）：
  - getToken 使用 `getTokenAppKey` 和 `getTokenAppSecret`（HMAC 密钥为 hex 解码）
  - checkToken 使用 `checkTokenAppKey` 和 `checkTokenAppSecret`（HMAC 密钥为 UTF-8 字符串）

### 2.2 请求协议

- **方法**：`POST`
- **协议**：HTTPS（推荐）或 HTTP
- **Content-Type**：`application/json`

### 2.3 请求路径

- **实际请求路径**：`/cube/external/checkToken`
- **签名使用路径**：`/external/checkToken`（⚠️ **无** `/cube` 前缀）

**完整 URL 示例**：

```
https://soho.komect.com/cube/external/checkToken
```

### 2.4 请求头

#### 2.4.1 参与签名的请求头（按字典序排序）

| 字段名 | 必填 | 示例值 | 说明 |
| :--- | :--- | :--- | :--- |
| `X-SOHOJS-Key` | 是 | `********************************` | 应用标识（由杭研提供） |
| `X-SOHOJS-Timestamp` | 是 | `1704067200000` | 毫秒时间戳（当前时间） |
| `X-SOHOJS-Uuid` | 是 | `550e8400-e29b-41d4-a716-446655440000` | UUID（**带连字符**，标准格式），每次请求重新生成 |
| `body` | 是 | `<Base64 字符串>` | 请求体 JSON 的 Base64 编码（见 2.5 节） |

**⚠️ 注意事项**：

- 所有参与签名的请求头按**字典序**（字母顺序）排列
- `X-SOHOJS-Uuid` 每次请求都必须重新生成，用于防重放攻击
- `body` 字段的值是请求体 JSON 的 Base64 编码，不是请求体本身

#### 2.4.2 不参与签名的请求头

| 字段名 | 必填 | 示例值 | 说明 |
| :--- | :--- | :--- | :--- |
| `X-SOHOJS-Signature` | 是 | `a1b2c3d4e5f6...` | HMAC-SHA256 签名（小写 hex），由签名算法计算得出 |
| `User-Agent` | 是 | `jtydn-1.0.0` | 用户代理，固定为 `jtydn-1.0.0` |
| `Content-Type` | 是 | `application/json` | 内容类型，固定为 `application/json` |

**⚠️ 注意事项**：

- `X-SOHOJS-Signature`、`User-Agent`、`Content-Type` **不参与**签名计算
- 签名字符串中只包含 2.4.1 节中列出的 4 个字段

### 2.5 请求体

#### 2.5.1 请求体 JSON 结构

```json
{
  "token": "********************************"
}
```

**字段说明**：

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `token` | string | 从 getToken 接口获取的 token 明文 |

#### 2.5.2 用于签名的 Base64 编码

将请求体 JSON 序列化为 UTF-8 字节后进行 Base64 编码：

```python
body_json = '{"token":"********************************"}'
body_base64 = base64.b64encode(body_json.encode('utf-8')).decode('utf-8')
```

**⚠️ 注意**：

- 签名使用的是 `bodyBase64`，不是请求体本身
- 签名字符串中 `body` 字段的值就是这个 Base64 字符串

### 2.6 签名算法

#### 2.6.1 签名字符串格式

```
POST&/external/checkToken&X-SOHOJS-Key=<appKey>&X-SOHOJS-Timestamp=<timestamp>&X-SOHOJS-Uuid=<uuid>&body=<bodyBase64>
```

**构造规则**：

1. 固定前缀：`POST&` + 签名路径（`/external/checkToken`）
2. 按**字典序**（字母顺序）添加字段：
   - `X-SOHOJS-Key=<appKey>`
   - `X-SOHOJS-Timestamp=<timestamp>`
   - `X-SOHOJS-Uuid=<uuid>`
   - `body=<bodyBase64>`

**⚠️ 注意事项**：

- 字段顺序按**字典序**排列（与 getToken 一致）
- `body` 字段的值是请求体 JSON 的 Base64 编码
- `X-SOHOJS-Signature`、`User-Agent`、`Content-Type` **不参与**签名
- `X-SOHOJS-Uuid` 每次请求都必须重新生成，用于防重放攻击

#### 2.6.2 HMAC 签名

- **算法**：HMAC-SHA256
- **密钥**：`checkTokenAppSecret`（UTF-8 字符串）直接按 UTF-8 编码为字节
- **输出**：小写十六进制字符串

**示例**：

```python
import hmac
import hashlib

# checkTokenAppSecret 是 UTF-8 字符串，直接编码为字节
checkTokenAppSecret = "********************************"
key_bytes = checkTokenAppSecret.encode('utf-8')

# 签名字符串
sign_payload = "POST&/external/checkToken&X-SOHOJS-Key=...&body=..."

# 计算 HMAC-SHA256
signature = hmac.new(key_bytes, sign_payload.encode('utf-8'), hashlib.sha256).hexdigest().lower()
```

### 2.7 响应格式

#### 2.7.1 成功响应示例

```json
{
  "code": "2000",
  "msg": "success",
  "data": {
    "nickname": "张三",
    "phone": "138****1234"
  }
}
```

#### 2.7.2 失败响应示例

```json
{
  "code": "5001",
  "msg": "Invalid token",
  "businessCode": "INVALID_TOKEN",
  "errMsg": "The provided token is invalid or expired"
}
```

#### 2.7.3 响应字段说明

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `code` | string | 业务状态码 |
| `msg` | string | 状态描述 |
| `data` | object | 用户信息对象 |
| `data.nickname` | string | 用户昵称 |
| `data.phone` | string | 手机号（可能已脱敏） |
| `businessCode` | string | 业务错误码（失败时） |
| `errMsg` | string | 错误详情（失败时） |

### 2.8 成功判定

**成功条件**（同时满足）：

1. HTTP 状态码为 `2xx`（通常是 200）
2. 响应体 JSON 的 `code` 字段等于 `"2000"`
3. `data` 字段是对象（不是数组或字符串）
4. `data.nickname` 和 `data.phone` 均为非空字符串

**⚠️ 注意**：

- `data` 必须是对象，不能是字符串
- `nickname` 和 `phone` 必须都非空

### 2.9 Python 代码示例

```python
#!/usr/bin/env python3
"""
杭研 SSO checkToken 接口 Python 实现示例
"""

import base64
import hashlib
import hmac
import json
import time
import uuid
import requests
from typing import Optional, Tuple


def generate_uuid_with_dash() -> str:
    """生成带连字符的标准 UUID"""
    return str(uuid.uuid4())


def hmac_sha256_hex_utf8(key: str, message: str) -> str:
    """计算 HMAC-SHA256（密钥为 UTF-8 字符串）并返回小写 hex 字符串"""
    key_bytes = key.encode('utf-8')
    return hmac.new(key_bytes, message.encode('utf-8'), hashlib.sha256).hexdigest().lower()


def build_sign_splice(
    sign_path: str,
    app_key: str,
    timestamp: int,
    uuid_val: str,
    body_base64: str
) -> str:
    """构建签名字符串（固定顺序）"""
    parts = [
        "POST",
        sign_path,
        f"X-SOHOJS-Key={app_key}",
        f"X-SOHOJS-Timestamp={timestamp}",
        f"X-SOHOJS-Uuid={uuid_val}",
        f"body={body_base64}",
    ]
    return "&".join(parts)


def hangyan_check_token(
    base_url: str,
    token: str,
    checkTokenAppKey: str,
    checkTokenAppSecret: str,
    http_timeout_ms: int = 4000
) -> Optional[Tuple[str, str]]:
    """
    调用杭研 checkToken 接口校验 token 并获取用户信息
    
    Args:
        base_url: 基础 URL，如 https://soho.komect.com
        token: 从 getToken 接口获取的 token
        checkTokenAppKey: 应用标识（从配置文件 `checkTokenAppKey` 获取）
        checkTokenAppSecret: HMAC 密钥（UTF-8 字符串，从配置文件 `checkTokenAppSecret` 获取）
        http_timeout_ms: HTTP 超时时间（毫秒）
    
    Returns:
        成功时返回 (nickname, phone) 元组，失败时返回 None
    
    ⚠️ 注意：
        getToken 和 checkToken 使用不同的 appKey 和 appSecret
    """
    # 请求路径
    request_path = "/cube/external/checkToken"
    sign_path = "/external/checkToken"  # 签名用，无 /cube 前缀
    
    # 生成请求参数
    uuid_val = generate_uuid_with_dash()
    timestamp = int(time.time() * 1000)
    
    # 构造请求体 JSON
    body_json = json.dumps({"token": token})
    
    # Base64 编码请求体（用于签名）
    body_base64 = base64.b64encode(body_json.encode('utf-8')).decode('utf-8')
    
    # 构建签名字符串（固定顺序）
    sign_splice = build_sign_splice(
        sign_path=sign_path,
        app_key=checkTokenAppKey,
        timestamp=timestamp,
        uuid_val=uuid_val,
        body_base64=body_base64
    )
    
    # 计算签名（checkTokenAppSecret 是 UTF-8 字符串，直接编码为字节）
    signature = hmac_sha256_hex_utf8(checkTokenAppSecret, sign_splice)
    
    # 构建请求头
    request_headers = {
        "X-SOHOJS-Key": checkTokenAppKey,
        "X-SOHOJS-Timestamp": str(timestamp),
        "X-SOHOJS-Uuid": uuid_val,
        "X-SOHOJS-Signature": signature,
        "User-Agent": "jtydn-1.0.0",
        "Content-Type": "application/json",
    }
    
    # 发送请求
    url = f"{base_url}{request_path}"
    try:
        response = requests.post(
            url,
            headers=request_headers,
            data=body_json,  # 直接使用 JSON 字符串，不是 Base64
            timeout=http_timeout_ms / 1000.0
        )
        
        # 检查 HTTP 状态码
        if response.status_code != 200:
            print(f"HTTP 错误：{response.status_code}")
            return None
        
        # 解析响应
        resp_json = response.json()
        code = resp_json.get("code")
        
        # 检查业务状态码（checkToken 成功码只有 "2000"）
        if code != "2000":
            msg = resp_json.get("msg", "")
            print(f"业务错误：code={code}, msg={msg}")
            return None
        
        # 提取用户信息
        data = resp_json.get("data")
        if not data or not isinstance(data, dict):
            print("data 字段缺失或不是对象")
            return None
        
        nickname = data.get("nickname", "")
        phone = data.get("phone", "")
        
        # 检查字段是否非空
        if not nickname or not nickname.strip():
            print("nickname 为空")
            return None
        if not phone or not phone.strip():
            print("phone 为空")
            return None
        
        return (nickname.strip(), phone.strip())
        
    except requests.exceptions.RequestException as e:
        print(f"网络错误：{e}")
        return None
    except json.JSONDecodeError as e:
        print(f"JSON 解析错误：{e}")
        return None


if __name__ == "__main__":
    # 配置参数
    BASE_URL = "https://soho.komect.com"
    TOKEN = "********************************"  # 从 getToken 接口获取
    CHECK_TOKEN_APP_KEY = "********************************"
    CHECK_TOKEN_APP_SECRET = "********************************"
    
    # 调用接口
    result = hangyan_check_token(
        base_url=BASE_URL,
        token=TOKEN,
        checkTokenAppKey=CHECK_TOKEN_APP_KEY,
        checkTokenAppSecret=CHECK_TOKEN_APP_SECRET
    )
    
    if result:
        nickname, phone = result
        print(f"校验成功：nickname={nickname}, phone={phone}")
    else:
        print("校验失败")
```

---

## 3. 错误处理

### 3.1 错误类型分类

| 错误类型 | 说明 | 处理方式 |
| :--- | :--- | :--- |
| **网络错误** | 超时、DNS 解析失败、连接拒绝等 | 可重试 |
| **HTTP 错误** | HTTP 状态码非 2xx | 根据状态码决定是否重试（502/503/504 可重试） |
| **业务错误** | 响应中 `code` 字段非成功码 | 不可重试，需检查请求参数 |
| **数据错误** | 响应 JSON 格式错误、字段缺失 | 不可重试，需检查接口契约 |
| **签名失败** | HMAC 签名失败 | 不可重试，需检查密钥配置 |

### 3.2 常见业务错误码

| 错误码 | 说明 |
| :--- | :--- |
| `2000` | 成功（getToken 和 checkToken 的成功码） |
| `5000` | 无效 vmid |
| `5001` | 无效 token |
| `5002` | token 已过期 |
| `5003` | 签名验证失败 |
| `5004` | 时间戳过期（请求时间与服务器时间差过大） |

---

## 附录 A：关键差异对比

| 特性 | getToken | checkToken |
| :--- | :--- | :--- |
| **请求路径** | `/terminal/token/sso/getToken/v1` | `/cube/external/checkToken` |
| **签名路径** | `/token/sso/getToken/v1`（无 /terminal） | `/external/checkToken`（无 /cube） |
| **请求头前缀** | `X-SOHO-*` | `X-SOHOJS-*` |
| **请求头排序** | 字典序 | 字典序 |
| **UUID 格式** | 无连字符（32 位 hex） | 带连字符（标准格式） |
| **HMAC 密钥** | hex 字符串解码为字节 | UTF-8 字符串直接编码 |
| **请求体** | 嵌套 JSON + Base64 | 简单 JSON |
| **返回数据** | `token`（`data` 是对象） | `nickname`, `phone`（`data` 是对象） |

**⚠️ 重要说明**：

- getToken 和 checkToken 使用**不同的** `appKey` 和 `appSecret`，不能混用
- 两个接口的请求头排序**都是字典序**

---

**参考文档**：

- 《家庭办公移动端接入文档.pdf》
- 《家庭办公平台接入文档.pdf》
