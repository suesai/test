/**
 * 平台入口：按操作系统提供 `getVmid`、`getHostSerialNumber`（实现位于 `vmid.ts`、`host-serial.ts`）。
 */
export { getVmid } from "./vmid.js";
export { getHostSerialNumber } from "./host-serial.js";
