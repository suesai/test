import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { platform } from "node:os";
import { SsoSystemError } from "../errors.js";

// --- Windows（`reg query` 读 `Ice-UUID`）
const VMID_REG_KEY = "HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment";
const VMID_VALUE_NAME = "Ice-UUID";

function parseRegQuerySzLine(stdout: string, valueName: string): string | null {
  const escaped = valueName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const lineRe = new RegExp(
    `^\\s*${escaped}\\s+REG_(?:EXPAND_)?SZ\\s+(.+)$`,
    "im",
  );
  const m = stdout.match(lineRe);
  return m?.[1] != null ? m[1] : null;
}

function vmidFromWindows(): string {
  let stdout: string;
  try {
    stdout = execFileSync("reg.exe", ["query", VMID_REG_KEY, "/v", VMID_VALUE_NAME], {
      windowsHide: true,
      encoding: "utf8",
    });
  } catch (e: unknown) {
    const err = e as { status?: number; stderr?: Buffer; stdout?: Buffer; message?: string };
    const detail =
      err.stderr?.toString("utf8").trim() ||
      err.stdout?.toString("utf8").trim() ||
      (e instanceof Error ? e.message : String(e));
    throw new SsoSystemError(`vmid: reg query failed: ${detail}`, { cause: e });
  }

  const vmid = parseRegQuerySzLine(stdout, VMID_VALUE_NAME);
  if (!vmid) {
    throw new SsoSystemError(
      `vmid: could not parse ${VMID_VALUE_NAME} from reg query output`,
    );
  }
  const trimmed = vmid.trim();
  if (!trimmed) {
    throw new SsoSystemError("vmid: Ice-UUID is empty");
  }
  return trimmed;
}

// --- Linux（`/etc/zxve/zxve.conf` 中 `[pmm]` / `key`）
const ZXVE_CONF_PATH = "/etc/zxve/zxve.conf";
const PMM_SECTION = "pmm";
const PMM_VMID_KEY = "key";

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function stripIniInlineComment(value: string): string {
  const t = value.trim();
  let cut = t.length;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (c === "#" || c === ";") {
      cut = i;
      break;
    }
  }
  return t.slice(0, cut).trim();
}

function parsePmmKeyFromIni(content: string): string | null {
  const lines = content.split(/\r?\n/);
  let inPmm = false;

  const sectionLine = /^\s*\[\s*([^\]]+?)\s*\]\s*$/;
  const keyLine = new RegExp(
    `^\\s*${escapeRegExp(PMM_VMID_KEY)}\\s*=\\s*(.*)$`,
    "i",
  );

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      continue;
    }
    if (/^[#;]/.test(trimmed)) {
      continue;
    }

    const sec = trimmed.match(sectionLine);
    if (sec) {
      inPmm = sec[1].trim().toLowerCase() === PMM_SECTION;
      continue;
    }

    if (!inPmm) {
      continue;
    }

    const kv = trimmed.match(keyLine);
    if (kv) {
      const rawVal = stripIniInlineComment(kv[1] ?? "");
      const value = rawVal.trim();
      return value.length > 0 ? value : null;
    }
  }

  return null;
}

function vmidFromLinux(): string {
  if (!existsSync(ZXVE_CONF_PATH)) {
    throw new SsoSystemError(`vmid: file not found: ${ZXVE_CONF_PATH}`);
  }

  let raw: string;
  try {
    raw = readFileSync(ZXVE_CONF_PATH, "utf8");
  } catch (e) {
    throw new SsoSystemError(
      `vmid: failed to read ${ZXVE_CONF_PATH}: ${e instanceof Error ? e.message : String(e)}`,
      { cause: e },
    );
  }

  if (raw.charCodeAt(0) === 0xfeff) {
    raw = raw.slice(1);
  }

  const vmid = parsePmmKeyFromIni(raw);
  if (!vmid) {
    throw new SsoSystemError(
      `vmid: [${PMM_SECTION}]/${PMM_VMID_KEY} not found or empty in ${ZXVE_CONF_PATH}`,
    );
  }
  return vmid;
}

/**
 * 解析当前操作系统下的 SSO vmid，供各局点 HTTP 使用（Windows 注册表、Linux zxve.conf）。
 */
export function getVmid(): string {
  const os = platform();
  if (os === "win32") {
    return vmidFromWindows();
  }
  if (os === "linux") {
    return vmidFromLinux();
  }
  throw new SsoSystemError(
    `vmid: unsupported operating system "${os}" (supported: win32, linux)`,
  );
}
