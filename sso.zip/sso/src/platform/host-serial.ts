import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { platform } from "node:os";
import { warn } from "../log.js";

const MACHINE_ID_PATH = "/etc/machine-id";

/** 取得序列失败时的占位，标准全零 nil UUID。 */
const UUID_ALL_ZERO = "00000000-0000-0000-0000-000000000000";

function formatMachineIdAsUuidIfNeeded(raw: string): string {
  const t = raw.trim().replace(/^\{|\}$/g, "");
  if (/^[0-9a-fA-F]{32}$/.test(t)) {
    const s = t.toLowerCase();
    return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20, 32)}`;
  }
  if (
    /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/i.test(
      t,
    )
  ) {
    return t.toLowerCase();
  }
  return raw.trim();
}

function hostSerialFromLinux(): string {
  const fail = (detail: string): string => {
    warn(
      `SSO host-serial: Linux 无法从 ${MACHINE_ID_PATH} 取得序列（${detail}），已用全零 nil UUID: ${UUID_ALL_ZERO}`,
    );
    return UUID_ALL_ZERO;
  };

  try {
    if (!existsSync(MACHINE_ID_PATH)) {
      return fail("文件不存在");
    }
    const line = readFileSync(MACHINE_ID_PATH, "utf8").split(/\r?\n/)[0]?.trim();
    if (line) {
      return formatMachineIdAsUuidIfNeeded(line);
    }
    return fail("文件为空或首行无内容");
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return fail(`读文件: ${msg}`);
  }
}

function hostSerialFromWindows(): string {
  const fail = (detail: string): string => {
    warn(
      `SSO host-serial: Windows 无法取得 BIOS 序列号（${detail}），已用全零 nil UUID: ${UUID_ALL_ZERO}`,
    );
    return UUID_ALL_ZERO;
  };

  try {
    const out = execFileSync("wmic", ["bios", "get", "serialnumber"], {
      encoding: "utf8",
      windowsHide: true,
    });
    const lines = out
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !/^serialnumber$/i.test(l));
    const sn = lines[0]?.trim();
    if (sn && !/^serialnumber$/i.test(sn)) {
      return sn;
    }
    return fail("wmic 无有效行");
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return fail(`wmic: ${msg}`);
  }
}

/**
 * 当前主机上的「设备序列」语义（Windows：BIOS；Linux：machine-id）。
 * 取不到或未支持的平台（非 win32/linux）时，返回全零 nil UUID 并打 `warn`。
 * 与 {@link getVmid} 独立：vmid 为业务侧设备标识，本接口偏硬件/系统指纹。
 */
export function getHostSerialNumber(): string {
  const os = platform();
  if (os === "win32") {
    return hostSerialFromWindows();
  }
  if (os === "linux") {
    return hostSerialFromLinux();
  }
  warn(
    `SSO host-serial: 未实现 ${os} 平台取序列，已用全零 nil UUID: ${UUID_ALL_ZERO}`,
  );
  return UUID_ALL_ZERO;
}
