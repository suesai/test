import { aesGcmDecrypt, aesGcmEncrypt } from "openclaw/plugin-sdk/coclaw";
import { error } from "./log.js";

/** 逻辑键 → 单字段 AES-256-GCM 密文（Base64 串），**一层**加解密。使用 OpenClaw SDK 内置 `aesGcmEncrypt`/`aesGcmDecrypt`，无需配置密钥。 */
const encryptedByKey = new Map<string, string>();

export type CredentialValue =
  | string
  | number
  | boolean
  | null
  | { [k: string]: CredentialValue }
  | CredentialValue[];

/** SSO 凭证数据：键为业务字段名，值为 JSON 兼容类型。 */
export type CredentialData = Record<string, CredentialValue>;

/**
 * 清空当前凭证。须先于 {@link addCredentialData} 调用一次。
 */
export function initCredential(): void {
  encryptedByKey.clear();
}

/**
 * 添加或替换凭证中的顶层键值对：键为明文，值支持 JSON 兼容类型；内存中仅保存**加密后的值**（每值一次 `aesGcmEncrypt`）。
 * 可多次调用，同顶层键会覆盖其值（**仅替换顶层 key 的 value，不深度合并**）。
 */
export function addCredentialData(plainByKey: CredentialData): void {
  for (const [k, value] of Object.entries(plainByKey)) {
    const name = k.trim();
    if (!name) {
      continue;
    }
    const serialized = JSON.stringify(value);
    encryptedByKey.set(name, aesGcmEncrypt(serialized));
  }
}

/**
 * 返回当前凭证中**全部**键值（解密后）。解密失败或其它异常时**打日志并返回空对象**（不抛错）。
 */
export function getCredentialData(): CredentialData {
  const out: CredentialData = {};
  try {
    for (const [k, enc] of encryptedByKey) {
      const raw = aesGcmDecrypt(enc);
      out[k] = JSON.parse(raw) as CredentialValue;
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    error(`decrypt or parse failed, returning empty object. ${msg}`);
    return {};
  }
  return out;
}
