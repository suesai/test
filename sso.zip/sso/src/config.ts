/**
 * `sso.json` 的加载与字段校验。
 * 配置文件不存在、解析失败或字段缺失时均抛出 `SsoConfigError`。
 * 
 * 缓存机制：`loadSsoJson` 缓存配置，`getSsoConfig` 用于获取缓存的配置。
 */
import { readFileSync } from "node:fs";
import { aesGcmDecrypt } from "openclaw/plugin-sdk/coclaw";
import { SsoConfigError } from "./errors.js";
import { warn } from "./log.js";

/** 全局缓存的 SSO 配置（加载后缓存） */
let cachedConfig: SsoJsonConfig | null = null;

/** 单次 `fetch` 超时的配置上限（ms），超过则压到此值。 */
const MAX_HTTP_TIMEOUT_MS = 32_000;

/**
 * 配置项 `httpRetryCount` 的上限；超出时由 {@link loadSsoJson} 钳制为该值并记录告警日志。
 */
const MAX_HTTP_RETRY_COUNT = 32;

/**
 * `httpTimeoutMs` 的默认值（ms）；未配置或非法时使用此值。
 */
const DEFAULT_HTTP_TIMEOUT_MS = 5_000;

/**
 * `httpRetryCount` 的默认值（总尝试次数，含第 1 次）；未配置或非法时使用此值。
 */
const DEFAULT_HTTP_RETRY_COUNT = 4;

export type SsoJsonConfig = {
  /** 局点标识（必选） */
  site: string;
  baseUrl?: string;
  /**
   * 单次 `fetch` 超时（ms），`AbortSignal.timeout`；加载时若超过 {@link MAX_HTTP_TIMEOUT_MS} 会压到该上限并打日志。
   * 未配或非法时由 {@link loadSsoJson} 赋值为 {@link DEFAULT_HTTP_TIMEOUT_MS}（**5000** ms）。
   */
  httpTimeoutMs?: number;
  /**
   * 与对端**每一段**独立 HTTP 流程的**总尝试次数**（含第 1 次），段与段之间互不影响。
   * 重试仅作用于 `isRetryableHttpError` 判定的可恢复错误（定义在 `site/http-helpers`）；未配或非法时由 {@link loadSsoJson} 赋值为 {@link DEFAULT_HTTP_RETRY_COUNT}（**4** 次）。
   */
  httpRetryCount?: number;
  /** 是否启用 debug 日志。仅在显式设置为 `true` 时开启。 */
  debug?: boolean;
  /** 杭研局点 */
  getTokenAppKey?: string;
  getTokenAppSecret?: string;
  checkTokenAppKey?: string;
  checkTokenAppSecret?: string;
  /** 联通局点 */
  rsaPublicKey?: string;
  rsaPrivateKey?: string;
};

/**
 * 加载 `sso.json` 配置文件。
 * 
 * 加载后缓存配置。
 * @param configPath 配置文件完整路径（例如：`/path/to/plugin/sso.json`）
 * @returns 配置对象；如果解析失败或字段缺失，抛出 `SsoConfigError`。
 */
export function loadSsoJson(configPath: string): SsoJsonConfig {
  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(configPath, "utf8"));
  } catch (e) {
    throw new SsoConfigError(`sso.json parse failed: ${configPath}`, { cause: e });
  }
  if (!raw || typeof raw !== "object") {
    throw new SsoConfigError("sso.json must be an object");
  }
  const o = raw as Record<string, unknown>;
  const site = typeof o.site === "string" ? o.site.trim() : "";
  const baseUrl = typeof o.baseUrl === "string" ? o.baseUrl.trim() : undefined;
  const debug = typeof o.debug === "boolean" ? o.debug : undefined;

  const rawHttpTimeoutMs =
    typeof o.httpTimeoutMs === "number" && Number.isFinite(o.httpTimeoutMs) && o.httpTimeoutMs > 0
      ? Math.floor(o.httpTimeoutMs) : DEFAULT_HTTP_TIMEOUT_MS;
  let httpTimeoutMs = rawHttpTimeoutMs;
  if (httpTimeoutMs > MAX_HTTP_TIMEOUT_MS) {
    warn(`sso.json 中 httpTimeoutMs=${rawHttpTimeoutMs} 超过上限 ${MAX_HTTP_TIMEOUT_MS}，限幅为 ${MAX_HTTP_TIMEOUT_MS} ms`);
    httpTimeoutMs = MAX_HTTP_TIMEOUT_MS;
  }

  const rawHttpRetryCount =
    typeof o.httpRetryCount === "number" && Number.isFinite(o.httpRetryCount) && o.httpRetryCount >= 1
      ? Math.floor(o.httpRetryCount) : DEFAULT_HTTP_RETRY_COUNT;
  let httpRetryCount = rawHttpRetryCount;
  if (httpRetryCount > MAX_HTTP_RETRY_COUNT) {
    warn(`sso.json 中 httpRetryCount=${rawHttpRetryCount} 超过上限 ${MAX_HTTP_RETRY_COUNT}，限幅为 ${MAX_HTTP_RETRY_COUNT} 次`);
    httpRetryCount = MAX_HTTP_RETRY_COUNT;
  }

  // 杭研密钥字段：配置文件中为 AES-GCM 加密存储，需要解密
  let getTokenAppKey: string | undefined;
  let getTokenAppSecret: string | undefined;
  let checkTokenAppKey: string | undefined;
  let checkTokenAppSecret: string | undefined;
  try {
    if (typeof o.getTokenAppKey === "string") {
      getTokenAppKey = aesGcmDecrypt(o.getTokenAppKey.trim());
    }
    if (typeof o.getTokenAppSecret === "string") {
      getTokenAppSecret = aesGcmDecrypt(o.getTokenAppSecret.trim());
    }
    if (typeof o.checkTokenAppKey === "string") {
      checkTokenAppKey = aesGcmDecrypt(o.checkTokenAppKey.trim());
    }
    if (typeof o.checkTokenAppSecret === "string") {
      checkTokenAppSecret = aesGcmDecrypt(o.checkTokenAppSecret.trim());
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    warn(`杭研密钥字段解密失败：${msg}`);
  }
  
  // 联通 RSA 密钥字段：配置文件中为 AES-GCM 加密存储，需要解密
  let rsaPublicKey: string | undefined;
  let rsaPrivateKey: string | undefined;
  try {
    if (typeof o.rsaPublicKey === "string") {
      rsaPublicKey = aesGcmDecrypt(o.rsaPublicKey.trim());
    }
    if (typeof o.rsaPrivateKey === "string") {
      rsaPrivateKey = aesGcmDecrypt(o.rsaPrivateKey.trim());
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    warn(`联通 RSA 密钥字段解密失败：${msg}`);
  }

  /** site 为必选字段 */
  if (!site) {
    throw new SsoConfigError("sso.json: site is required");
  }

  // 根据局点进行字段校验并返回配置对象
  const cfg: SsoJsonConfig = {
    site,
    httpTimeoutMs,
    httpRetryCount,
    debug,
    baseUrl,
    getTokenAppKey,
    getTokenAppSecret,
    checkTokenAppKey,
    checkTokenAppSecret,
    rsaPublicKey,
    rsaPrivateKey,
  };

  if (site === "hangyan") {
    if (!cfg.baseUrl) {
      throw new SsoConfigError("[hangyan] sso.json must define baseUrl for hangyan site");
    }
    if (!cfg.getTokenAppKey) {
      throw new SsoConfigError("[hangyan] sso.json must define getTokenAppKey for hangyan site");
    }
    if (!cfg.getTokenAppSecret) {
      throw new SsoConfigError("[hangyan] sso.json must define getTokenAppSecret for hangyan site");
    }
    if (!cfg.checkTokenAppKey) {
      throw new SsoConfigError("[hangyan] sso.json must define checkTokenAppKey for hangyan site");
    }
    if (!cfg.checkTokenAppSecret) {
      throw new SsoConfigError("[hangyan] sso.json must define checkTokenAppSecret for hangyan site");
    }
  } else if (site === "unicom") {
    if (!cfg.baseUrl) {
      throw new SsoConfigError("[unicom] sso.json must define baseUrl for this site");
    }
    if (!cfg.rsaPublicKey) {
      throw new SsoConfigError("[unicom] sso.json must define rsaPublicKey for this site");
    }
    if (!cfg.rsaPrivateKey) {
      throw new SsoConfigError("[unicom] sso.json must define rsaPrivateKey for this site");
    }
  } else {
    throw new SsoConfigError(`sso.json: unknown site "${site}"`);
  }
  
  // 加载成功后更新缓存
  cachedConfig = cfg;
  return cfg;
}

/**
 * 获取缓存的 SSO 配置。
 * 
 * @returns 缓存的配置，如果尚未加载或文件不存在则返回 `null`。
 */
export function getSsoConfig(): SsoJsonConfig | null {
  return cachedConfig;
}
