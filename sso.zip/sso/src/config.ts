/**
 * `sso.json` 的加载与字段校验；路径拼接使用 Node `path`。主机标识 `vmid` 由 `platform/` 提供，与本模块无关。
 * 配置文件不存在时返回 `null`（静默跳过 SSO），解析失败或字段缺失时抛出 `SsoConfigError`。
 */
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { SsoConfigError } from "./errors.js";
import { warn } from "./log.js";

/** 单次 `fetch` 超时的配置上限（ms），超过则压到此值。 */
const MAX_HTTP_TIMEOUT_MS = 32_000;

/**
 * 配置项 `httpRetryCount` 的上限；超出时由 {@link loadSsoJson} 钳制为该值并记录告警日志。
 */
const MAX_HTTP_RETRY_COUNT = 32;

/**
 * `httpTimeoutMs` 的默认值（ms）；未配置或非法时使用此值。
 */
const DEFAULT_HTTP_TIMEOUT_MS = 5_000;

/**
 * `httpRetryCount` 的默认值（总尝试次数，含第 1 次）；未配置或非法时使用此值。
 */
const DEFAULT_HTTP_RETRY_COUNT = 4;

export type SsoJsonConfig = {
  /** 局点标识（必选） */
  site: string;
  baseUrl?: string;
  /**
   * 单次 `fetch` 超时（ms），`AbortSignal.timeout`；加载时若超过 {@link MAX_HTTP_TIMEOUT_MS} 会压到该上限并打日志。
   * 未配或非法时由 {@link loadSsoJson} 赋值为 {@link DEFAULT_HTTP_TIMEOUT_MS}（**5000** ms）。
   */
  httpTimeoutMs: number;
  /**
   * 与对端**每一段**独立 HTTP 流程的**总尝试次数**（含第 1 次），段与段之间互不影响。
   * 重试仅作用于 `isRetryableHttpError` 判定的可恢复错误（定义在 `site/http-helpers`）；未配或非法时由 {@link loadSsoJson} 赋值为 {@link DEFAULT_HTTP_RETRY_COUNT}（**4** 次）。
   */
  httpRetryCount: number;
  /** 是否启用 debug 日志。仅在显式设置为 `true` 时开启。 */
  debug?: boolean;
  /** 杭研局点：getToken API 的 appKey */
  getTokenAppKey?: string;
  /** 杭研局点：getToken API 的 appSecret（HMAC 密钥，hex 解码） */
  getTokenAppSecret?: string;
  /** 杭研局点：checkToken API 的 appKey */
  checkTokenAppKey?: string;
  /** 杭研局点：checkToken API 的 appSecret（HMAC 密钥，UTF-8 编码） */
  checkTokenAppSecret?: string;
  /** 联通局点：RSA 公钥（Base64 PEM 格式，加密请求） */
  rsaPublicKey?: string;
  /** 联通局点：RSA 私钥（Base64 PEM 格式，解密响应） */
  rsaPrivateKey?: string;
};

/**
 * 加载 `sso.json` 配置文件。
 * @returns 如果配置文件不存在，返回 `null`（表示跳过 SSO）；如果解析失败或字段缺失，抛出 `SsoConfigError`。
 */
export function loadSsoJson(pluginRootDir: string): SsoJsonConfig | null {
  const p = path.join(pluginRootDir, "sso.json");
  if (!existsSync(p)) {
    warn(`sso.json not found: ${p}, SSO will be skipped`);
    return null;
  }
  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(p, "utf8"));
  } catch (e) {
    throw new SsoConfigError(`sso.json parse failed: ${p}`, { cause: e });
  }
  if (!raw || typeof raw !== "object") {
    throw new SsoConfigError("sso.json must be an object");
  }
  const o = raw as Record<string, unknown>;
  const site = typeof o.site === "string" ? o.site.trim() : "";
  const baseUrl = typeof o.baseUrl === "string" ? o.baseUrl.trim() : undefined;
  const debug = typeof o.debug === "boolean" ? o.debug : undefined;
  const getTokenAppKey = typeof o.getTokenAppKey === "string" && o.getTokenAppKey.trim() ? o.getTokenAppKey.trim() : undefined;
  const getTokenAppSecret = typeof o.getTokenAppSecret === "string" && o.getTokenAppSecret.trim() ? o.getTokenAppSecret.trim() : undefined;
  const checkTokenAppKey = typeof o.checkTokenAppKey === "string" && o.checkTokenAppKey.trim() ? o.checkTokenAppKey.trim() : undefined;
  const checkTokenAppSecret = typeof o.checkTokenAppSecret === "string" && o.checkTokenAppSecret.trim() ? o.checkTokenAppSecret.trim() : undefined;
  const rsaPublicKey = typeof o.rsaPublicKey === "string" && o.rsaPublicKey.trim() ? o.rsaPublicKey.trim() : undefined;
  const rsaPrivateKey = typeof o.rsaPrivateKey === "string" && o.rsaPrivateKey.trim() ? o.rsaPrivateKey.trim() : undefined;

  const rawHttpTimeoutMs =
    typeof o.httpTimeoutMs === "number" && Number.isFinite(o.httpTimeoutMs) && o.httpTimeoutMs > 0
      ? Math.floor(o.httpTimeoutMs) : DEFAULT_HTTP_TIMEOUT_MS;
  let httpTimeoutMs = rawHttpTimeoutMs;
  if (httpTimeoutMs > MAX_HTTP_TIMEOUT_MS) {
    warn(`SSO: sso.json 中 httpTimeoutMs=${rawHttpTimeoutMs} 超过上限 ${MAX_HTTP_TIMEOUT_MS}，限幅为 ${MAX_HTTP_TIMEOUT_MS} ms`);
    httpTimeoutMs = MAX_HTTP_TIMEOUT_MS;
  }

  const rawHttpRetryCount =
    typeof o.httpRetryCount === "number" && Number.isFinite(o.httpRetryCount) && o.httpRetryCount >= 1
      ? Math.floor(o.httpRetryCount) : DEFAULT_HTTP_RETRY_COUNT;
  let httpRetryCount = rawHttpRetryCount;
  if (httpRetryCount > MAX_HTTP_RETRY_COUNT) {
    warn(`SSO: sso.json 中 httpRetryCount=${rawHttpRetryCount} 超过上限 ${MAX_HTTP_RETRY_COUNT}，限幅为 ${MAX_HTTP_RETRY_COUNT} 次`);
    httpRetryCount = MAX_HTTP_RETRY_COUNT;
  }

  /** site 为必选字段 */
  if (!site) {
    throw new SsoConfigError("sso.json: site is required");
  }

  return {
    site,
    baseUrl,
    httpTimeoutMs,
    httpRetryCount,
    debug,
    getTokenAppKey,
    getTokenAppSecret,
    checkTokenAppKey,
    checkTokenAppSecret,
    rsaPublicKey,
    rsaPrivateKey,
  };
}
