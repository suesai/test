/**
 * SSO 流程编排：加载 `sso.json` → 按 `site` 执行站点逻辑（`site/`）。
 * 各局点在需要时自行获取 `vmid`。
 */
import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { loadSsoJson } from "./config.js";
import { isSsoError } from "./errors.js";
import { clearCredential } from "./credential.js";
import { initLog, info, warn } from "./log.js";
import { runSite } from "./site/index.js";

/** SSO 是否已就绪（配置文件存在且 SSO 流程已成功完成）。内部状态，不对外暴露。 */
let isReady = false;

export function checkIsReady(): boolean {
  return isReady;
}

export async function runSso(params: { pluginRootDir: string; runtime: OpenClawPluginApi["runtime"] }): Promise<void> {
  const cfg = loadSsoJson(params.pluginRootDir);

  // 配置文件不存在时，静默跳过 SSO 流程（不抛出错误）
  if (!cfg) {
    warn("SSO skipped due to missing configuration file");
    isReady = false;
    return;
  }

  // 初始化日志系统
  initLog(cfg.debug);
  
  clearCredential();

  info(`SSO start site=${cfg.site} baseUrl=${cfg.baseUrl ?? "not configured"}`);
  await runSite(cfg, params.runtime);
  info("SSO success");
  
  // 标记 SSO 已就绪
  isReady = true;
}

export function formatSsoFailure(err: unknown): { code: string; message: string } {
  if (isSsoError(err)) {
    const code = (err as Error & { code?: string }).code ?? "Error";
    return { code, message: err.message };
  }
  if (err instanceof Error) {
    return { code: err.name, message: err.message };
  }
  return { code: "Error", message: String(err) };
}
