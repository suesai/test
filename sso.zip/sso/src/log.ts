import { createHash } from "node:crypto";
import { homedir } from "node:os";
import path from "node:path";
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";

/** 日志目录：`~/.openclaw/logs` */
const LOG_DIR = path.join(homedir(), ".openclaw", "logs");
/** 日志文件路径：`~/.openclaw/logs/sso.log` */
const LOG_FILE_PATH = path.join(LOG_DIR, "sso.log");
/** 备份文件路径：`~/.openclaw/logs/sso.log.bak` */
const LOG_BACKUP_PATH = path.join(LOG_DIR, "sso.log.bak");
/** 日志文件大小上限：8MB */
const MAX_LOG_SIZE = 8 * 1024 * 1024;
/** 单条日志最大长度：4096 字节 */
const MAX_LOG_LENGTH = 4096;

/** 日志级别 */
export type SsoLogLevel = "error" | "warn" | "info" | "debug";

/** 各日志级别前缀的固定宽度 */
const LEVEL_WIDTH = 5; // ERROR, WARN, INFO, DEBUG

/** 文件：函数：行号的最大宽度 */
const LOCATION_WIDTH = 32; // file:func:line

/** PID:TID 的最大宽度 */
const PID_TID_WIDTH = 12; // pid:tid

/** 时间戳宽度 */
const TIME_WIDTH = 23; // YYYY-MM-DD HH:MM:SS.mmm

/** 是否已初始化 */
let initialized = false;
/** 是否启用 debug 日志 */
let debugEnabled = false;

/**
 * 初始化日志系统：创建日志目录，检查日志文件大小，必要时备份。
 * 必须在插件启动时调用一次。
 * @param enableDebug 是否启用 debug 日志。只有当此参数为 `true` 时才开启 debug 日志。
 */
export function initLog(enableDebug: boolean | undefined = undefined): void {
  if (initialized) {
    return;
  }
  
  try {
    if (!existsSync(LOG_DIR)) {
      mkdirSync(LOG_DIR, { recursive: true });
    }
    
    // 检查日志文件大小
    if (existsSync(LOG_FILE_PATH)) {
      const stats = statSync(LOG_FILE_PATH);
      if (stats.size >= MAX_LOG_SIZE) {
        // 备份旧日志
        if (existsSync(LOG_BACKUP_PATH)) {
          try {
            writeFileSync(LOG_BACKUP_PATH, "", "utf8");
          } catch {
            // ignore
          }
        }
        renameSync(LOG_FILE_PATH, LOG_BACKUP_PATH);
      }
    }
    
    // 只有显式传入 true 才开启 debug 日志
    debugEnabled = enableDebug === true;
    initialized = true;
  } catch (err) {
    // 初始化失败，使用 console 打印错误信息
    console.error("[SSO] log initialization failed:", err instanceof Error ? err.message : String(err));
    initialized = false;
  }
}

/**
 * 获取定长的时间戳字符串：`YYYY-MM-DD HH:MM:SS.mmm`
 */
function formatTimestamp(): string {
  const now = new Date();
  const year = String(now.getFullYear()).padStart(4, "0");
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");
  const milliseconds = String(now.getMilliseconds()).padStart(3, "0");
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
}

/**
 * 获取定长的 PID:TID 字符串
 */
function formatPidTid(): string {
  const pid = process.pid;
  const tid = 0; // Node.js 单线程模型，固定为 0
  return `${pid}:${tid}`.padStart(PID_TID_WIDTH, " ");
}

/**
 * 获取定长的日志级别字符串
 */
function formatLevel(level: SsoLogLevel): string {
  return level.toUpperCase().padEnd(LEVEL_WIDTH, " ");
}

/**
 * 获取调用位置信息：`file:func:line`
 */
function formatLocation(): string {
  const err = new Error();
  const stack = err.stack;
  if (!stack) {
    return "unknown:unknown:0".padEnd(LOCATION_WIDTH, " ");
  }
  
  const lines = stack.split("\n");
  // 跳过前 5 行：
  // 0: Error 行
  // 1: formatLocation 调用行
  // 2: formatLogLine 调用行
  // 3: writeLog 调用行
  // 4: info/warn/error/debug 调用行
  // 5+: 真正的调用者
  for (let i = 5; i < lines.length; i++) {
    const line = lines[i];
    const match = line.match(/at\s+(?:async\s+)?(?:[^\s]+\s+)?\((.+):(\d+):(\d+)\)/);
    if (match) {
      const filePath = match[1];
      const lineNum = match[2];
      // 提取文件名
      const fileName = path.basename(filePath, ".ts");
      // 提取函数名（如果有）
      const funcMatch = line.match(/at\s+(?:async\s+)?([^\s(]+)\s+\(/);
      const funcName = funcMatch ? funcMatch[1].split(".").pop() || "unknown" : "unknown";
      return `${fileName}:${funcName}:${lineNum}`.padEnd(LOCATION_WIDTH, " ");
    }
  }
  
  return "unknown:unknown:0".padEnd(LOCATION_WIDTH, " ");
}

/**
 * 格式化日志行
 */
function formatLogLine(level: SsoLogLevel, message: string): string {
  const time = formatTimestamp();
  const pidTid = formatPidTid();
  const levelStr = formatLevel(level);
  const location = formatLocation();
  
  // 截断过长的消息
  let msg = message;
  if (Buffer.byteLength(msg, "utf8") > MAX_LOG_LENGTH) {
    const encoder = new TextEncoder();
    const bytes = encoder.encode(msg);
    const truncated = bytes.subarray(0, MAX_LOG_LENGTH);
    msg = new TextDecoder().decode(truncated);
  }
  
  return `[${time}] [${pidTid}] [${levelStr}] [${location}] ${msg}\n`;
}

/**
 * 写入日志到文件
 */
function writeLog(level: SsoLogLevel, message: string): void {
  // 若日志系统未初始化（初始化失败），则直接返回
  if (!initialized) {
    return;
  }
  
  // 检查 debug 级别是否启用
  if (level === "debug" && !debugEnabled) {
    return;
  }
  
  try {
    // 每次写日志前检查文件大小
    if (existsSync(LOG_FILE_PATH)) {
      const stats = statSync(LOG_FILE_PATH);
      if (stats.size >= MAX_LOG_SIZE) {
        // 备份旧日志
        if (existsSync(LOG_BACKUP_PATH)) {
          try {
            writeFileSync(LOG_BACKUP_PATH, "", "utf8");
          } catch {
            // ignore
          }
        }
        renameSync(LOG_FILE_PATH, LOG_BACKUP_PATH);
      }
    }
    
    const logLine = formatLogLine(level, message);
    appendFileSync(LOG_FILE_PATH, logLine, "utf8");
  } catch {
    // 写入失败，忽略（不 fallback）
  }
}

export function error(message: string): void {
  writeLog("error", `[SSO] ${message}`);
}

export function warn(message: string): void {
  writeLog("warn", `[SSO] ${message}`);
}

export function info(message: string): void {
  writeLog("info", `[SSO] ${message}`);
}

export function debug(message: string): void {
  writeLog("debug", `[SSO] ${message}`);
}

/** 与 `apps/app-desktop/src/telemetry/gatewayTelemetry.ts` 的 `GATEWAY_TOKEN_STORAGE_KEY` 相同，值为 `gateway-token`。 */
const GATEWAY_TOKEN_STORAGE_KEY = "gateway-token";

/** 埋点 `POST /api/telemetry/events` 使用的本机网关 HTTP 基址（固定 `127.0.0.1:18789`）。 */
const TELEMETRY_GATEWAY_BASE_URL = "http://127.0.0.1:18789";

/**
 * 解析 Bearer Token：优先从 `localStorage` 读取 `gateway-token`；若失败则从环境变量获取；若依然获取失败，则从配置文件获取；若最终获取失败，则打印日志。
 */
function resolveGatewayTokenForTelemetry(): string | undefined {
  let stored: string | null = null;
  try {
    const ls = (globalThis as { localStorage?: { getItem: (key: string) => string | null } })
      .localStorage;
    if (ls) {
      stored = ls.getItem(GATEWAY_TOKEN_STORAGE_KEY);
    }
  } catch {
    stored = null;
  }
  const fromStorage = stored?.trim() || null;
  if (fromStorage) {
    return fromStorage;
  }
  
  // localStorage 获取失败，尝试从环境变量获取
  const envToken = process.env.OPENCLAW_GATEWAY_TOKEN?.trim();
  if (envToken) {
    return envToken;
  }

  // 环境变量获取失败，从配置文件获取
  const stateDir = process.env.OPENCLAW_STATE_DIR?.trim() || path.join(homedir(), ".openclaw");
  const configPath = path.join(stateDir, "openclaw.json");
  try {
    const cfg = JSON.parse(readFileSync(configPath, "utf-8"));
    const t = cfg?.gateway?.auth?.token?.trim();
    if (t) {
      return t;
    }
  } catch {
    // ignore
  }
  
  // 最终获取失败，打印日志
  warn("无法获取 gateway token：localStorage、环境变量与配置文件均未找到");
  return undefined;
}

/** SSO 插件埋点请求体（POST `/api/telemetry/events`），`source` 使用 `plugin`。 */
type TelemetryEventRequestBody = {
  schemaVersion: string;
  eventName: string;
  source: "plugin";
  timestamp: number;
  properties: Record<string, unknown>;
};

/**
 * 向本机网关 `POST /api/telemetry/events` 上报埋点；请求体包含 `schemaVersion`、`eventName`、`source: "plugin"`、`timestamp`、`properties`。
 */
export async function reportTelemetryEventToGateway(
  properties: Record<string, unknown>,
): Promise<void> {
  const baseUrl = TELEMETRY_GATEWAY_BASE_URL.replace(/\/+$/, "");
  const eventNameRaw = properties.event_type;
  const eventName =
    typeof eventNameRaw === "string" && eventNameRaw.trim() ? eventNameRaw.trim() : "unknown";
  const body: TelemetryEventRequestBody = {
    schemaVersion: "1.0.0",
    eventName,
    source: "plugin",
    timestamp: Date.now(),
    properties,
  };
  const url = `${baseUrl}/api/telemetry/events`;
  try {
    const token = resolveGatewayTokenForTelemetry();
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      credentials: "include",
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const message = await res.text().catch(() => "");
      warn(
        `埋点上报网关失败：HTTP ${res.status}${message ? ` ${message.slice(0, 120)}` : ""}`,
      );
    }
  } catch (e) {
    warn(`埋点上报网关失败：${e instanceof Error ? e.message : String(e)}`);
  }
}

/** 敏感字段：仅输出 SHA-256 十六进制短前缀，便于关联 */
export function sensitiveHash(label: string, value: string, prefixLen = 16): string {
  const h = createHash("sha256").update(value, "utf8").digest("hex");
  return `${h.slice(0, prefixLen)}…`;
}
