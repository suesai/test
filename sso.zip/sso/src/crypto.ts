/**
 * 加密解密模块：提供 AES-256-GCM 加解密能力
 */
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { SsoCryptoError } from "./errors.js";

/**
 * 密钥：32 字节（256 位）
 */
const SECRET_KEY_HEX = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
const SECRET_KEY = Buffer.from(SECRET_KEY_HEX, "hex");

/** AES-GCM IV 长度（12 字节） */
const GCM_IV_LENGTH = 12;

/**
 * AES-256-GCM 加密
 * @param plaintext 明文
 * @returns 加密后的字符串（base64 编码，包含 IV、密文和认证标签）
 */
export function aes256Encrypt(plaintext: string): string {
  // 生成随机 IV
  const iv = randomBytes(GCM_IV_LENGTH);
  
  // 创建加密器
  const cipher = createCipheriv("aes-256-gcm", SECRET_KEY, iv);
  
  // 加密数据
  let ciphertext = cipher.update(plaintext, "utf8", "base64");
  ciphertext += cipher.final("base64");
  
  // 获取认证标签
  const authTag = cipher.getAuthTag().toString("base64");
  
  // 拼接：iv:ciphertext:authTag
  return `${iv.toString("base64")}:${ciphertext}:${authTag}`;
}

/**
 * AES-256-GCM 解密
 * @param encrypted 加密后的字符串（base64 编码，包含 IV、密文和认证标签）
 * @returns 解密后的明文
 */
export function aes256Decrypt(encrypted: string): string {
  const parts = encrypted.split(":");
  if (parts.length !== 3) {
    throw new SsoCryptoError("Invalid encrypted data format");
  }
  
  const [ivBase64, ciphertext, authTagBase64] = parts;
  
  // 转换输入数据
  const ivBuffer = Buffer.from(ivBase64, "base64");
  const authTagBuffer = Buffer.from(authTagBase64, "base64");
  
  // 创建解密器
  const decipher = createDecipheriv("aes-256-gcm", SECRET_KEY, ivBuffer);
  decipher.setAuthTag(authTagBuffer);
  
  // 解密数据
  let plaintext = decipher.update(ciphertext, "base64", "utf8");
  plaintext += decipher.final("utf8");
  
  return plaintext;
}
