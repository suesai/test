export class SsoConfigError extends Error {
  readonly code = "SsoConfigError";
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SsoConfigError";
  }
}

export class SsoNetworkError extends Error {
  readonly code = "SsoNetworkError";
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SsoNetworkError";
  }
}

export class SsoSystemError extends Error {
  readonly code = "SsoSystemError";
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SsoSystemError";
  }
}

export class SsoRuntimeError extends Error {
  readonly code = "SsoRuntimeError";
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SsoRuntimeError";
  }
}

/** HTTP 相关的运行时错误，携带 HTTP 状态码以便重试决策 */
export class SsoHttpError extends SsoRuntimeError {
  readonly httpStatus: number;
  constructor(message: string, httpStatus: number, options?: ErrorOptions) {
    super(message, options);
    this.httpStatus = httpStatus;
    this.name = "SsoHttpError";
  }
}

/** AES-GCM 解密封包、HMAC 密钥十六进制等密码学管线上的本模块主动抛错。使用 SDK 内置加密接口时可能抛出。 */
export class SsoCryptoError extends Error {
  readonly code = "SsoCryptoError";
  constructor(message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SsoCryptoError";
  }
}

/**
 * 判断是否为 SSO 自定义错误（通过 `code` 属性识别）
 */
export function isSsoError(err: unknown): err is Error & { code: string } {
  return err instanceof Error && typeof (err as Error & { code?: unknown }).code === "string";
}

/**
 * 格式化 SSO 错误为统一的错误码和消息
 * - 如果是 SSO 自定义错误，返回其 `code` 和 `message`
 * - 如果是普通 Error，返回 `name` 和 `message`
 * - 否则返回通用错误信息
 */
export function formatSsoFailure(err: unknown): { code: string; message: string } {
  if (isSsoError(err)) {
    return { code: err.code, message: err.message };
  }
  if (err instanceof Error) {
    return { code: err.name, message: err.message };
  }
  return { code: "Error", message: String(err) };
}
