/**
 * 各局点共用的出站 HTTP 工具：URL 拼接、JSON 标量转字符串、可重试错误判定、重试前等待。
 * 单局点专有实现（如杭研 Soho 签名与请求路径）位于 `site/<局点>/`。
 */
import { SsoHttpError, SsoNetworkError, SsoRuntimeError } from "../errors.js";

// --- 请求 URL 与 JSON 业务字段 ---

/**
 * `baseUrl` 与以 `/` 开头的 path 拼接；会去掉 `baseUrl` 尾部多余 `/`。
 */
export function joinBasePath(baseUrl: string, p: string): string {
  const b = baseUrl.replace(/\/+$/, "");
  const x = p.startsWith("/") ? p : `/${p}`;
  return b + x;
}

/**
 * 将 JSON 中可能是 `string` / `number` 等的标量拉成**日志/拼接用字符串**；
 * `undefined` / `null` 为 `""`。
 */
export function jsonScalarString(v: unknown): string {
  if (v === undefined || v === null) {
    return "";
  }
  return String(v);
}

/**
 * 响应体 `msg` 转为可写入日志/错误串的文本；**不在此截断**，长度由 `log` 等实现处理。
 */
export function responseMessageText(msg: unknown): string {
  if (typeof msg !== "string" || !msg) {
    return "no_msg";
  }
  return msg.trim();
}

// --- 重试 ---

/** 可触发重试的 HTTP 状态码集合；`isRetryableHttpError` 从 `SsoRuntimeError` 消息中解析状态码时依此判定。 */
const TRANSIENT_HTTP = new Set([502, 503, 504]);

const RETRY_BACKOFF_MS = 300;

/**
 * 同一业务操作内，**两次完整 HTTP 尝试**（含新签名、新 `fetch`）之间的等待。
 * 与单次 `httpTimeoutMs` 无关，仅作退避；与 {@link isRetryableHttpError} 搭配使用。
 */
export function waitBeforeHttpRetry(): Promise<void> {
  return new Promise((r) => setTimeout(r, RETRY_BACKOFF_MS));
}

/**
 * 是否应在**同一次**业务操作内再次发起 HTTP（新签名、新 `fetch`）。
 * - 任意 `SsoNetworkError`（含单次 `fetch` 超时/中断）
 * - `SsoHttpError` 且 HTTP 状态码为 502/503/504
 */
export function isRetryableHttpError(err: unknown): boolean {
  if (err instanceof SsoNetworkError) {
    return true;
  }
  if (err instanceof SsoHttpError) {
    return TRANSIENT_HTTP.has(err.httpStatus);
  }
  return false;
}
