/**
 * 杭研 HMAC 辅助方法（由 get-token、check-token 使用）。
 * getToken 使用 hex 解码的密钥，checkToken 使用 UTF-8 编码的密钥。
 */
import { createHmac } from "node:crypto";
import { SsoCryptoError } from "../../errors.js";

/**
 * 杭研 getToken：`getTokenAppSecret` 为十六进制串，先解码为字节再作为 HMAC-SHA256 密钥。
 * @param hex 十六进制字符串（长度必须为偶数）
 * @returns 解码后的字节 Buffer
 */
export function hexToBytes(hex: string): Buffer {
  const t = hex.trim();
  if (t.length % 2 !== 0) {
    throw new SsoCryptoError("getTokenAppSecret: invalid hex length");
  }
  return Buffer.from(t, "hex");
}

/**
 * 计算 HMAC-SHA256 并返回小写十六进制字符串。
 * @param key 密钥字节 Buffer
 * @param payload 待签名字符串
 * @returns 小写十六进制签名字符串
 */
export function hmacSha256HexLower(key: Buffer, payload: string): string {
  return createHmac("sha256", key).update(payload, "utf8").digest("hex");
}

/**
 * 杭研 checkToken：`checkTokenAppSecret` 按 UTF-8 取字节作为 HMAC-SHA256 密钥。
 * @param secretUtf8 UTF-8 字符串密钥
 * @param payload 待签名字符串
 * @returns 小写十六进制签名字符串
 */
export function hmacSha256HexLowerUtf8Secret(secretUtf8: string, payload: string): string {
  return createHmac("sha256", Buffer.from(secretUtf8, "utf8")).update(payload, "utf8").digest("hex");
}
