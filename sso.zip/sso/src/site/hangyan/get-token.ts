/**
 * 杭研 getToken API 实现：`POST /terminal/token/sso/getToken/v1`。
 * HMAC 签名的路径为 `/token/sso/getToken/v1`（无 `/terminal` 前缀）。
 * 使用 `getTokenAppKey` 和 `getTokenAppSecret`（hex 解码）进行签名。
 */
import { randomUUID } from "node:crypto";
import { SsoHttpError, SsoNetworkError, SsoRuntimeError, SsoSystemError } from "../../errors.js";
import {
  debug,
  error,
  info,
  reportTelemetryEventToGateway,
  sensitiveHash,
  warn,
} from "../../log.js";
import type { HostSnapshot } from "./host-snapshot.js";
import { getHostSnapshot } from "./host-snapshot.js";
import {
  isRetryableHttpError,
  joinBasePath,
  jsonScalarString,
  responseMessageText,
  waitBeforeHttpRetry,
} from "../http-helpers.js";
import { hexToBytes, hmacSha256HexLower } from "./hmac.js";

const REQUEST_PATH = "/terminal/token/sso/getToken/v1";
const SIGN_PATH = "/token/sso/getToken/v1";

/**
 * 内层 JSON 字段 `type`：**接入方类型**；**杭研局点**为 **6**。
 * 与签名字节串 `bodyData` 一起出现在 `{ "type", "data" }` 中，其中 `data` 为 `JSON.stringify({ vmid })`。
 */
const ACCESSOR_TYPE = 6;

/** 杭研 getToken 响应体 JSON 的 `code` 表示成功时的取值。 */
const GET_TOKEN_SUCCESS_CODE = "2000";

const NETWORK_STATUS = "0";
const CARRIER = "1";

function buildAppTypeLine(host: HostSnapshot): string {
  return `${host.osName}|${host.osVersion}|${host.osName}|${NETWORK_STATUS}|${CARRIER}|${host.serialNumber}|`;
}

function buildRomVersion(host: HostSnapshot): string {
  return `${host.osName}-${host.osVersion}-${host.osRelease}`;
}

function extractToken(data: unknown): string | null {
  if (data !== null && typeof data === "object" && !Array.isArray(data)) {
    const t = (data as Record<string, unknown>).token;
    if (typeof t === "string" && t.trim()) {
      return t.trim();
    }
  }
  if (typeof data === "string" && data.trim()) {
    try {
      const inner = JSON.parse(data) as unknown;
      if (inner !== null && typeof inner === "object" && !Array.isArray(inner)) {
        const t = (inner as Record<string, unknown>).token;
        if (typeof t === "string" && t.trim()) {
          return t.trim();
        }
      }
    } catch {
      return null;
    }
  }
  return null;
}

function buildGetTokenSignString(
  headersSortedKeys: string[],
  headerMap: Record<string, string | number>,
  bodyData: string,
): string {
  let s = `POST&${SIGN_PATH}`;
  for (const k of headersSortedKeys) {
    if (k === "X-SOHO-Signature" || k === "User-Agent") {
      continue;
    }
    s += `&${k}=`;
    const v = headerMap[k];
    if (v != null) {
      s += String(v);
    }
  }
  s += `&body=${bodyData}`;
  return s;
}

function logRequest(params: {
  url: string;
  signPath: string;
  uuid: string;
  timestamp: number;
  innerJson: string;
  bodyData: string;
  finalBody: string;
  sortedSignKeys: string[];
  signHeaders: Record<string, string | number>;
  signPayload: string;
  getTokenAppKey: string;
  getTokenAppSecret: string;
  signature: string;
  requestHeaders: Record<string, string>;
}): void {
  info("========================================");
  info("Soho getToken 请求 (杭研)");
  info(`原始 JSON: ${params.innerJson}`);
  const headerLines: string[] = [];
  for (const k of params.sortedSignKeys) {
    const v = params.signHeaders[k];
    const valueStr = String(v ?? "");
    headerLines.push(`${k}=${k === "X-SOHO-SohoToken" ? sensitiveHash("sohoToken", valueStr) : valueStr}`);
  }
  const nonSignHeaders: Array<[string, string]> = [];
  for (const [k, v] of Object.entries(params.requestHeaders)) {
    if (!params.sortedSignKeys.includes(k)) {
      nonSignHeaders.push([k, v]);
    }
  }
  nonSignHeaders.sort((a, b) => a[0].localeCompare(b[0]));
  for (const [k, v] of nonSignHeaders) {
    headerLines.push(`${k}=${k === "X-SOHO-SohoToken" ? sensitiveHash("sohoToken", v) : v}`);
  }
  info(`Headers: ${headerLines.join("; ")}`);
  info(`最终请求体：${params.finalBody}`);
  info(`Method: POST | URL: ${params.url} | uuid: ${params.uuid} | Timestamp: ${params.timestamp} | signPath: ${params.signPath}`);
  info("========================================");
}

function sohoGetTokenResponseDebug(httpStatus: number, bodyText: string, durationMs: number): void {
  info("========================================");
  info("Soho getToken 响应");
  info(`状态码：${httpStatus} durationMs=${durationMs}`);
  const tokenMasked = bodyText.replace(/"token"\s*:\s*"([^"]+)"/g, (match, token) => {
    return `"token":"${sensitiveHash("token", token)}"`;
  });
  info(`响应体：${tokenMasked}`);
  debug(`完整响应体：${bodyText}`);
  info("========================================");
}

function sohoGetTokenNetworkFailDebug(err: unknown, durationMs: number, url: string): void {
  const msg = err instanceof Error ? err.message : String(err);
  debug(`网络/超时失败：${url} durationMs=${durationMs} err=${msg}`);
}

async function reportGetTokenResultTelemetry(params: {
  durationMs: number;
  ok: boolean;
  reason?: string;
  httpStatus?: number;
}): Promise<void> {
  await reportTelemetryEventToGateway({
    event_type: "sso",
    sso_site: "hangyan",
    sso_api: "get-token",
    sso_ok: params.ok,
    sso_duration_ms: params.durationMs,
    ...(params.reason ? { sso_failure_reason: params.reason } : {}),
    ...(params.httpStatus !== undefined ? { sso_http_status: params.httpStatus } : {}),
  });
}

export async function hangyanGetToken(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  httpRetryCount: number;
  vmid: string;
  getTokenAppKey: string;
  getTokenAppSecret: string;
}): Promise<string> {
  const max = params.httpRetryCount;
  for (let i = 0; i < max; i++) {
    if (i > 0) {
      await waitBeforeHttpRetry();
      warn(`getToken will retry (attempt ${i + 1}/${max}) after transient failure`);
    }
    try {
      return await hangyanGetTokenOnce(params);
    } catch (e) {
      if (i < max - 1 && isRetryableHttpError(e)) {
        continue;
      }
      const errMsg = e instanceof Error ? e.message : String(e);
      if (i === max - 1) {
        error(
          `getToken: 重试已用尽 (共 ${max} 次)，仍失败，即将向上抛出：${errMsg}`,
        );
      } else {
        error(
          `getToken: 第 ${i + 1}/${max} 次失败，错误不可重试或非瞬时，即将抛出：${errMsg}`,
        );
      }
      throw e;
    }
  }
  throw new SsoRuntimeError("getToken: retry loop ended without return");
}

async function hangyanGetTokenOnce(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  vmid: string;
  getTokenAppKey: string;
  getTokenAppSecret: string;
}): Promise<string> {
  const url = joinBasePath(params.baseUrl, REQUEST_PATH);
  const host = getHostSnapshot();
  const uuid = randomUUID().replace(/-/g, "");
  const timestamp = Date.now();
  const appType = buildAppTypeLine(host);
  const romVersion = buildRomVersion(host);

  const dataInnerStr = JSON.stringify({ vmid: params.vmid });
  const innerJson = JSON.stringify({
    type: ACCESSOR_TYPE,
    data: dataInnerStr,
  });
  const bodyData = Buffer.from(innerJson, "utf8").toString("base64");
  const finalBody = JSON.stringify({ data: bodyData });

  const signHeaders: Record<string, string | number> = {
    "X-SOHO-AppKey": params.getTokenAppKey,
    "X-SOHO-AppType": appType,
    "X-SOHO-ClientVersion": "1.0.0",
    "X-SOHO-DeviceId": params.vmid,
    "X-SOHO-RomVersion": romVersion,
    "X-SOHO-Timestamp": String(timestamp),
    "X-SOHO-UserId": "-1",
    "X-SOHO-Uuid": uuid,
    "X-SOHO-VersionNum": 1,
  };

  const sortedKeys = Object.keys(signHeaders).sort((a, b) => a.localeCompare(b));
  const signPayload = buildGetTokenSignString(sortedKeys, signHeaders, bodyData);

  let signature: string;
  try {
    const keyBuf = hexToBytes(params.getTokenAppSecret);
    signature = hmacSha256HexLower(keyBuf, signPayload);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    error(`getToken sign error: ${msg}`);
    throw new SsoSystemError(`getToken: signature failed: ${msg}`, { cause: e });
  }

  const requestHeaders: Record<string, string> = {
    ...Object.fromEntries(Object.entries(signHeaders).map(([k, v]) => [k, String(v)] as [string, string])),
    "X-SOHO-Signature": signature,
    "X-SOHO-SohoToken": "",
    "User-Agent": "jtydn-1.0.0",
    "Content-Type": "application/json",
  };

  sohoGetTokenInfoLine({
    url,
    uuid,
    timestamp,
    appKey: params.getTokenAppKey,
    appSecret: params.getTokenAppSecret,
    signature,
  });
  logRequest({
    url,
    signPath: SIGN_PATH,
    uuid,
    timestamp,
    innerJson,
    bodyData,
    finalBody,
    sortedSignKeys: sortedKeys,
    signHeaders,
    signPayload,
    getTokenAppKey: params.getTokenAppKey,
    getTokenAppSecret: params.getTokenAppSecret,
    signature,
    requestHeaders,
  });

  const started = Date.now();
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: requestHeaders,
      body: finalBody,
      signal: AbortSignal.timeout(params.httpTimeoutMs),
    });
  } catch (e) {
    const durationMs = Date.now() - started;
    sohoGetTokenNetworkFailDebug(e, durationMs, url);
    const reason = `network: ${e instanceof Error ? e.message : String(e)}`;
    warn(`getToken failed: durationMs=${durationMs} reason=${reason}`);
    await reportGetTokenResultTelemetry({ ok: false, durationMs, reason });
    throw new SsoNetworkError(`getToken fetch failed: ${e instanceof Error ? e.message : String(e)}`, {
      cause: e,
    });
  }

  const httpStatus = res.status;
  const text = await res.text();
  const durationMs = Date.now() - started;
  sohoGetTokenResponseDebug(httpStatus, text, durationMs);
  let json: unknown;
  try {
    json = text ? JSON.parse(text) : null;
  } catch (e) {
    warn(`getToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=invalid_json_body`);
    await reportGetTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "invalid_json_body",
    });
    throw new SsoHttpError(`getToken: response is not JSON (${httpStatus})`, httpStatus, { cause: e });
  }

  const o = json as Record<string, unknown> | null;
  if (!o) {
    warn(`getToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=empty_body`);
    await reportGetTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "empty_body",
    });
    throw new SsoHttpError("getToken: empty response", httpStatus);
  }

  if (!res.ok) {
    const codeStr = jsonScalarString(o.code);
    const msg = responseMessageText(o.msg);
    warn(`getToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=http_not_2xx code=${codeStr} msg=${msg}`);
    await reportGetTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `http_not_2xx code=${codeStr} msg=${msg}`,
    });
    throw new SsoHttpError(`getToken: HTTP ${httpStatus} code=${codeStr} ${msg}`, httpStatus);
  }

  const codeStr = jsonScalarString(o.code);
  if (codeStr !== GET_TOKEN_SUCCESS_CODE) {
    const msg = responseMessageText(o.msg);
    const businessCodeStr = jsonScalarString(o.businessCode);
    const err = jsonScalarString(o.errMsg);
    const reason = `api_code 非 ${GET_TOKEN_SUCCESS_CODE}: code=${codeStr} msg=${msg} errMsg=${err} businessCode=${businessCodeStr}`;
    warn(`getToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=${reason}`);
    await reportGetTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `api_code_non_success ${reason}`,
    });
    throw new SsoRuntimeError(`getToken: API code ${codeStr} (${msg})`);
  }

  const token = extractToken(o.data);
  if (!token) {
    warn(`getToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=missing_token`);
    await reportGetTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "missing_token",
    });
    throw new SsoHttpError("getToken: token missing in data", httpStatus);
  }

  sohoGetTokenResponseDebug(httpStatus, text, durationMs);
  await reportGetTokenResultTelemetry({ ok: true, durationMs, httpStatus });
  return token;
}

function sohoGetTokenInfoLine(params: {
  url: string;
  uuid: string;
  timestamp: number;
  appKey: string;
  appSecret: string;
  signature: string;
}): void {
  info(
    `Soho [getToken] POST ${params.url} uuid=${params.uuid} ts=${params.timestamp} ` +
    `appKey=${sensitiveHash("appKey", params.appKey)} ` +
    `appSecret=${sensitiveHash("appSecret", params.appSecret)} ` +
    `signature=${params.signature}`,
  );
}
