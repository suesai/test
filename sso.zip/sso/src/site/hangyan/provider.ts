/**
 * 杭研局点 SSO 实现：调用 getToken → checkToken，将 token、nickname、phone 存入凭证（内存加密）。
 */
import type { SsoJsonConfig } from "../../config.js";
import { SsoConfigError } from "../../errors.js";
import { initCredential, addCredentialData } from "../../credential.js";
import { hangyanCheckToken } from "./check-token.js";
import { hangyanGetToken } from "./get-token.js";
import { getVmid } from "../../platform/vmid.js";
import { info } from "../../log.js";

export async function runHangyanSso(params: {
  cfg: SsoJsonConfig;
}): Promise<void> {
  const { cfg } = params;
  const vmid = getVmid();

  // 初始化凭证（清空旧数据）
  initCredential();

  const token = await hangyanGetToken({
    baseUrl: cfg.baseUrl!,
    httpTimeoutMs: cfg.httpTimeoutMs!,
    httpRetryCount: cfg.httpRetryCount!,
    vmid,
    getTokenAppKey: cfg.getTokenAppKey!,
    getTokenAppSecret: cfg.getTokenAppSecret!,
  });

  const { nickname, phone } = await hangyanCheckToken({
    baseUrl: cfg.baseUrl!,
    httpTimeoutMs: cfg.httpTimeoutMs!,
    httpRetryCount: cfg.httpRetryCount!,
    tokenPlain: token,
    checkTokenAppKey: cfg.checkTokenAppKey!,
    checkTokenAppSecret: cfg.checkTokenAppSecret!,
  });

  addCredentialData({
    token,
    nickname,
    phone,
  });
}

/**
 * 杭研局点：仅打印日志，不执行实际操作
 */
export async function updateHangyanModelConfig(cfg: SsoJsonConfig): Promise<void> {
  // 杭研局点没有实际的模型配置更新逻辑，仅记录日志
  info(`updateModelConfig: no-op for hangyan site, baseUrl=${cfg.baseUrl ?? "not configured"}`);
}
