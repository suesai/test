/**
 * 杭研局点 SSO 实现：调用 getToken → checkToken，将 token、nickname、phone 存入凭证（内存加密）。
 */
import type { SsoJsonConfig } from "../../config.js";
import { SsoConfigError } from "../../errors.js";
import { initCredential, addCredentialData } from "../../credential.js";
import { hangyanCheckToken } from "./check-token.js";
import { hangyanGetToken } from "./get-token.js";
import { getVmid } from "../../platform/vmid.js";

export async function runHangyanSso(params: {
  cfg: SsoJsonConfig;
}): Promise<void> {
  const { cfg } = params;
  const vmid = getVmid();

  // 检查杭研局点必填字段（baseUrl 和四键）
  if (!cfg.baseUrl) {
    throw new SsoConfigError("hangyan: sso.json must define baseUrl for this site");
  }
  if (!cfg.getTokenAppKey) {
    throw new SsoConfigError("hangyan: sso.json must define getTokenAppKey for this site");
  }
  if (!cfg.getTokenAppSecret) {
    throw new SsoConfigError("hangyan: sso.json must define getTokenAppSecret for this site");
  }
  if (!cfg.checkTokenAppKey) {
    throw new SsoConfigError("hangyan: sso.json must define checkTokenAppKey for this site");
  }
  if (!cfg.checkTokenAppSecret) {
    throw new SsoConfigError("hangyan: sso.json must define checkTokenAppSecret for this site");
  }

  // 初始化凭证（清空旧数据）
  initCredential();

  const token = await hangyanGetToken({
    baseUrl: cfg.baseUrl,
    httpTimeoutMs: cfg.httpTimeoutMs,
    httpRetryCount: cfg.httpRetryCount,
    vmid,
    getTokenAppKey: cfg.getTokenAppKey,
    getTokenAppSecret: cfg.getTokenAppSecret,
  });

  const { nickname, phone } = await hangyanCheckToken({
    baseUrl: cfg.baseUrl,
    httpTimeoutMs: cfg.httpTimeoutMs,
    httpRetryCount: cfg.httpRetryCount,
    tokenPlain: token,
    checkTokenAppKey: cfg.checkTokenAppKey,
    checkTokenAppSecret: cfg.checkTokenAppSecret,
  });

  addCredentialData({
    token,
    nickname,
    phone,
  });
}
