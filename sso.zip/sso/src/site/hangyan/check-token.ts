/**
 * 杭研 checkToken API 实现：`POST /cube/external/checkToken`。
 * HMAC 签名的路径为 `/external/checkToken`（无 `/cube` 前缀）。
 * 使用 `checkTokenAppKey` 和 `checkTokenAppSecret`（UTF-8 编码）进行签名。
 */
import { randomUUID } from "node:crypto";
import { SsoHttpError, SsoNetworkError, SsoRuntimeError, SsoSystemError } from "../../errors.js";
import {
  debug,
  error,
  info,
  reportTelemetryEventToGateway,
  sensitiveHash,
  warn,
} from "../../log.js";
import {
  isRetryableHttpError,
  joinBasePath,
  jsonScalarString,
  responseMessageText,
  waitBeforeHttpRetry,
} from "../http-helpers.js";
import { hmacSha256HexLowerUtf8Secret } from "./hmac.js";

const REQUEST_PATH = "/cube/external/checkToken";
const SIGN_PATH = "/external/checkToken";

/** 杭研 checkToken 响应体 JSON 的 `code` 表示成功时的取值。 */
const CHECK_TOKEN_SUCCESS_CODE = "2000";

function buildCheckTokenSignSplice(params: {
  appKey: string;
  timestamp: number;
  uuid: string;
  bodyBase64: string;
}): string {
  const { appKey, timestamp, uuid, bodyBase64 } = params;
  return [
    "POST",
    SIGN_PATH,
    `X-SOHOJS-Key=${appKey}`,
    `X-SOHOJS-Timestamp=${timestamp}`,
    `X-SOHOJS-Uuid=${uuid}`,
    `body=${bodyBase64}`,
  ].join("&");
}

function sohoCheckTokenRequestDebugBlock(params: {
  url: string;
  signPath: string;
  uuid: string;
  timestamp: number;
  bodyJson: string;
  bodyBase64: string;
  splice: string;
  checkTokenAppKey: string;
  checkTokenAppSecret: string;
  signature: string;
  requestHeaders: Record<string, string>;
}): void {
  info("========================================");
  info("Soho checkToken 请求 (杭研)");
  info(`uuid: ${params.uuid}`);
  info(`Timestamp: ${params.timestamp}`);
  info(`signPath(签名路径): ${params.signPath}`);
  info(`body JSON: ${params.bodyJson}`);
  debug(`body Base64: ${params.bodyBase64}`);
  debug(`appKey 完整值：${params.checkTokenAppKey}`);
  debug(`checkTokenAppSecret(UTF-8 完整值): ${params.checkTokenAppSecret}`);
  debug("--- 签名字符串 splice ---");
  debug(params.splice);
  debug(`X-SOHOJS-Key: ${params.checkTokenAppKey}`);
  debug(`checkTokenAppSecret(UTF-8): ${params.checkTokenAppSecret}`);
  debug(`signature(小写十六进制): ${params.signature}`);
  debug("--- 发送 HTTP ---");
  debug("Method: POST");
  debug(`URL: ${params.url}`);
  const headerLines: string[] = [];
  const signKeys = ["X-SOHOJS-Key", "X-SOHOJS-Timestamp", "X-SOHOJS-Uuid"];
  for (const k of signKeys) {
    if (params.requestHeaders[k]) {
      headerLines.push(`${k}=${params.requestHeaders[k]}`);
    }
  }
  const nonSignHeaders: Array<[string, string]> = [];
  for (const [k, v] of Object.entries(params.requestHeaders)) {
    if (!signKeys.includes(k)) {
      nonSignHeaders.push([k, v]);
    }
  }
  nonSignHeaders.sort((a, b) => a[0].localeCompare(b[0]));
  for (const [k, v] of nonSignHeaders) {
    headerLines.push(`${k}=${v}`);
  }
  debug(`Headers: ${headerLines.join("; ")}`);
  debug(`Body: ${params.bodyJson}`);
  info("========================================");
}

function sohoCheckTokenResponseDebug(httpStatus: number, bodyText: string, durationMs: number): void {
  info("========================================");
  info("Soho checkToken 响应");
  info(`状态码：${httpStatus} durationMs=${durationMs}`);
  const tokenMasked = bodyText.replace(/"token"\s*:\s*"([^"]+)"/g, (match, token) => {
    return `"token":"${sensitiveHash("token", token)}"`;
  });
  const nicknameMasked = tokenMasked.replace(/"nickname"\s*:\s*"([^"]+)"/g, (match, nickname) => {
    return `"nickname":"${sensitiveHash("nickname", nickname)}"`;
  });
  const phoneMasked = nicknameMasked.replace(/"phone"\s*:\s*"([^"]+)"/g, (match, phone) => {
    return `"phone":"${sensitiveHash("phone", phone)}"`;
  });
  info(`响应体：${phoneMasked}`);
  debug(`完整响应体：${bodyText}`);
  info("========================================");
}

function sohoCheckTokenNetworkFailDebug(err: unknown, durationMs: number, url: string): void {
  const msg = err instanceof Error ? err.message : String(err);
  debug(`网络/超时失败：${url} durationMs=${durationMs} err=${msg}`);
}

async function reportCheckTokenResultTelemetry(params: {
  durationMs: number;
  ok: boolean;
  reason?: string;
  httpStatus?: number;
}): Promise<void> {
  await reportTelemetryEventToGateway({
    event_type: "sso",
    sso_site: "hangyan",
    sso_api: "check-token",
    sso_ok: params.ok,
    sso_duration_ms: params.durationMs,
    ...(params.reason ? { sso_failure_reason: params.reason } : {}),
    ...(params.httpStatus !== undefined ? { sso_http_status: params.httpStatus } : {}),
  });
}

export async function hangyanCheckToken(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  httpRetryCount: number;
  tokenPlain: string;
  checkTokenAppKey: string;
  checkTokenAppSecret: string;
}): Promise<{ nickname: string; phone: string }> {
  const max = params.httpRetryCount;
  for (let i = 0; i < max; i++) {
    if (i > 0) {
      await waitBeforeHttpRetry();
      warn(`checkToken will retry (attempt ${i + 1}/${max}) after transient failure`);
    }
    try {
      return await hangyanCheckTokenOnce(params);
    } catch (e) {
      if (i < max - 1 && isRetryableHttpError(e)) {
        continue;
      }
      const errMsg = e instanceof Error ? e.message : String(e);
      if (i === max - 1) {
        error(
          `checkToken: 重试已用尽 (共 ${max} 次)，仍失败，即将向上抛出：${errMsg}`,
        );
      } else {
        error(
          `checkToken: 第 ${i + 1}/${max} 次失败，错误不可重试或非瞬时，即将抛出：${errMsg}`,
        );
      }
      throw e;
    }
  }
  throw new SsoRuntimeError("checkToken: retry loop ended without return");
}

async function hangyanCheckTokenOnce(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  tokenPlain: string;
  checkTokenAppKey: string;
  checkTokenAppSecret: string;
}): Promise<{ nickname: string; phone: string }> {
  const url = joinBasePath(params.baseUrl, REQUEST_PATH);
  const uuid = randomUUID();
  const timestamp = Date.now();
  const bodyJson = JSON.stringify({ token: params.tokenPlain });
  const bodyBase64 = Buffer.from(bodyJson, "utf8").toString("base64");

  const splice = buildCheckTokenSignSplice({
    appKey: params.checkTokenAppKey,
    timestamp,
    uuid,
    bodyBase64,
  });

  let signature: string;
  try {
    signature = hmacSha256HexLowerUtf8Secret(params.checkTokenAppSecret, splice);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    error(`checkToken sign error: ${msg}`);
    throw new SsoSystemError(`checkToken: signature failed: ${msg}`, { cause: e });
  }

  const requestHeaders: Record<string, string> = {
    "X-SOHOJS-Key": params.checkTokenAppKey,
    "X-SOHOJS-Timestamp": String(timestamp),
    "X-SOHOJS-Uuid": uuid,
    "X-SOHOJS-Signature": signature,
    "User-Agent": "jtydn-1.0.0",
    "Content-Type": "application/json",
  };

  sohoCheckTokenInfoLine({
    url,
    uuid,
    timestamp,
    tokenPlain: params.tokenPlain,
    checkTokenAppKey: params.checkTokenAppKey,
    checkTokenAppSecret: params.checkTokenAppSecret,
    signature,
  });
  sohoCheckTokenRequestDebugBlock({
    url,
    signPath: SIGN_PATH,
    uuid,
    timestamp,
    bodyJson,
    bodyBase64,
    splice,
    checkTokenAppKey: params.checkTokenAppKey,
    checkTokenAppSecret: params.checkTokenAppSecret,
    signature,
    requestHeaders,
  });

  const started = Date.now();
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: requestHeaders,
      body: bodyJson,
      signal: AbortSignal.timeout(params.httpTimeoutMs),
    });
  } catch (e) {
    const durationMs = Date.now() - started;
    sohoCheckTokenNetworkFailDebug(e, durationMs, url);
    const reason = `network: ${e instanceof Error ? e.message : String(e)}`;
    warn(`checkToken failed: durationMs=${durationMs} reason=${reason}`);
    await reportCheckTokenResultTelemetry({ ok: false, durationMs, reason });
    throw new SsoNetworkError(`checkToken fetch failed: ${e instanceof Error ? e.message : String(e)}`, {
      cause: e,
    });
  }

  const httpStatus = res.status;
  const text = await res.text();
  const durationMs = Date.now() - started;
  sohoCheckTokenResponseDebug(httpStatus, text, durationMs);
  let json: unknown;
  try {
    json = text ? JSON.parse(text) : null;
  } catch (e) {
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=invalid_json_body`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "invalid_json_body",
    });
    throw new SsoHttpError(`checkToken: response is not JSON (${httpStatus})`, httpStatus, { cause: e });
  }

  const o = json as Record<string, unknown> | null;
  if (!o) {
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=empty_body`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "empty_body",
    });
    throw new SsoHttpError("checkToken: empty response", httpStatus);
  }

  if (!res.ok) {
    const codeStr = jsonScalarString(o.code);
    const msg = responseMessageText(o.msg);
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=http_not_2xx code=${codeStr} msg=${msg}`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `http_not_2xx code=${codeStr} msg=${msg}`,
    });
    throw new SsoHttpError(`checkToken: HTTP ${httpStatus} code=${codeStr} ${msg}`, httpStatus);
  }

  const codeStr = jsonScalarString(o.code);
  if (codeStr !== CHECK_TOKEN_SUCCESS_CODE) {
    const msg = responseMessageText(o.msg);
    const businessCodeStr = jsonScalarString(o.businessCode);
    const err = jsonScalarString(o.errMsg);
    const reason = `api_code 非 ${CHECK_TOKEN_SUCCESS_CODE}: code=${codeStr} msg=${msg} errMsg=${err} businessCode=${businessCodeStr}`;
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=${reason}`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `api_code_non_success ${reason}`,
    });
    throw new SsoRuntimeError(`checkToken: API code ${codeStr} (${msg})`);
  }

  const data = o.data;
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=missing_data`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "missing_data",
    });
    throw new SsoHttpError("checkToken: missing data", httpStatus);
  }
  const d = data as Record<string, unknown>;
  const nickname = typeof d.nickname === "string" ? d.nickname : "";
  const phone = typeof d.phone === "string" ? d.phone : "";
  if (!nickname.trim() || !phone.trim()) {
    warn(`checkToken failed: durationMs=${durationMs} httpStatus=${httpStatus} reason=missing_nickname_or_phone`);
    await reportCheckTokenResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "missing_nickname_or_phone",
    });
    throw new SsoHttpError("checkToken: nickname or phone missing", httpStatus);
  }

  sohoCheckTokenResponseDebug(httpStatus, text, durationMs);
  await reportCheckTokenResultTelemetry({ ok: true, durationMs, httpStatus });
  return { nickname: nickname.trim(), phone: phone.trim() };
}

function sohoCheckTokenInfoLine(params: {
  url: string;
  uuid: string;
  timestamp: number;
  tokenPlain: string;
  checkTokenAppKey: string;
  checkTokenAppSecret: string;
  signature: string;
}): void {
  info(
    `Soho [checkToken] POST ${params.url} uuid=${params.uuid} ts=${params.timestamp} ` +
    `token=${sensitiveHash("token", params.tokenPlain)} ` +
    `appKey=${sensitiveHash("appKey", params.checkTokenAppKey)} ` +
    `appSecret=${sensitiveHash("appSecret", params.checkTokenAppSecret)} ` +
    `signature=${params.signature}`,
  );
}
