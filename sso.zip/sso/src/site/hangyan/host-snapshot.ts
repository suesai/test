import { platform, release } from "node:os";
import { warn } from "../../log.js";
import { getHostSerialNumber } from "../../platform/host-serial.js";

/**
 * 杭研 getToken 请求体元数据所需的主机视图；由本局点组装，依赖平台 {@link getHostSerialNumber}，不含系统命令。
 */
export type HostSnapshot = {
  osName: string;
  osVersion: string;
  osRelease: string;
  serialNumber: string;
};

function safeKernelRelease(): string {
  try {
    return release();
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    warn(`SSO host-snapshot: os.release() 失败，osRelease 置为 0。${msg}`);
    return "0";
  }
}

/**
 * 读取本机 OS 分段信息，并调用平台侧 {@link getHostSerialNumber} 得到序列号。
 */
export function getHostSnapshot(): HostSnapshot {
  const plat = platform();
  const serialNumber = getHostSerialNumber();
  const rel = safeKernelRelease();

  if (plat === "win32") {
    const parts = rel.split(".");
    return {
      osName: "Windows",
      osVersion: parts[0] ?? "0",
      osRelease: parts[2] ?? parts[1] ?? "0",
      serialNumber,
    };
  }
  if (plat === "linux") {
    const parts = rel.split(".");
    return {
      osName: "Linux",
      osVersion: parts[0] ?? "0",
      osRelease: parts.slice(0, 3).join(".") || rel,
      serialNumber,
    };
  }
  return {
    osName: plat,
    osVersion: "0",
    osRelease: rel,
    serialNumber,
  };
}
