/**
 * 联通局点 SSO 实现：调用 getUnionAiKeyByResourceId，将 apiKey、llmName、llmUrl 存入凭证（内存加密）并写入 openclaw.json。
 */
import type { SsoJsonConfig } from "../../config.js";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { SsoConfigError, SsoRuntimeError } from "../../errors.js";
import { addCredentialData } from "../../credential.js";
import { info, warn } from "../../log.js";
import { getUnionAiKey } from "./get-union-ai-key.js";

export async function runUnicomSso(params: {
  cfg: SsoJsonConfig;
  runtime: OpenClawPluginApi["runtime"];
}): Promise<void> {
  const { cfg, runtime } = params;

  // 检查联通局点必填字段（baseUrl 和 RSA 密钥）
  if (!cfg.baseUrl) {
    throw new SsoConfigError("unicom: sso.json must define baseUrl for this site");
  }
  if (!cfg.rsaPublicKey) {
    throw new SsoConfigError("unicom: sso.json must define rsaPublicKey for this site");
  }
  if (!cfg.rsaPrivateKey) {
    throw new SsoConfigError("unicom: sso.json must define rsaPrivateKey for this site");
  }

  const { apiKey, llmName, llmUrl } = await getUnionAiKey({
    baseUrl: cfg.baseUrl,
    httpTimeoutMs: cfg.httpTimeoutMs,
    httpRetryCount: cfg.httpRetryCount,
    rsaPublicKey: cfg.rsaPublicKey,
    rsaPrivateKey: cfg.rsaPrivateKey,
  });

  // 联通局点失败时不退出，仅记录日志
  if (!apiKey || !llmName || !llmUrl) {
    warn("SSO unicom: API returned empty apiKey/llmName/llmUrl, continuing without SSO");
    return;
  }

  // 将凭证存入内存（加密）
  addCredentialData({
    apiKey,
    llmName,
    llmUrl,
  });

  // 写入 openclaw.json（仅联通局点需要）
  await writeUnicomConfig(runtime, { apiKey, llmName, llmUrl });
}

/**
 * 将联通 AI 配置写入 openclaw.json
 */
async function writeUnicomConfig(
  runtime: OpenClawPluginApi["runtime"],
  config: { apiKey: string; llmName: string; llmUrl: string },
): Promise<void> {
  if (!runtime?.config) {
    warn("SSO unicom: runtime.config not available, skipping openclaw.json write");
    return;
  }

  try {
    // 读取当前配置
    const cfg = JSON.parse(JSON.stringify(runtime.config.loadConfig())) as Record<string, unknown>;

    // 构建 models.providers 配置
    const modelsRoot = ensureObject(cfg, "models");
    const providers = ensureObject(modelsRoot, "providers");
    
    // 提取 provider baseUrl
    const providerBaseUrl = normalizeOpenAiBaseUrl(config.llmUrl);
    
    // apiKey 经过 aesGcmEncrypt 加密
    const { aesGcmEncrypt } = await import("openclaw/plugin-sdk/coclaw");
    const encryptedApiKey = aesGcmEncrypt(config.apiKey);
    
    providers["default-model"] = {
      baseUrl: providerBaseUrl,
      apiKey: encryptedApiKey,
      models: [
        {
          id: config.llmName,
          name: config.llmName,
        },
      ],
    };

    // 构建 agents.defaults.model 配置
    const agentsRoot = ensureObject(cfg, "agents");
    const defaults = ensureObject(agentsRoot, "defaults");
    const model = ensureObject(defaults, "model");
    model.primary = `default-model/${config.llmName}`;

    // 写入配置文件
    await runtime.config.writeConfigFile(cfg);
    info(`SSO unicom: config written to openclaw.json (provider=default-model, model=${config.llmName})`);
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    warn(`SSO unicom: failed to write openclaw.json: ${errMsg}`);
    throw new SsoRuntimeError(`SSO unicom: config write failed: ${errMsg}`, { cause: err });
  }
}

function ensureObject(root: Record<string, unknown>, key: string): Record<string, unknown> {
  const existing = root[key];
  if (existing && typeof existing === "object" && existing !== null) {
    return existing as Record<string, unknown>;
  }
  const next: Record<string, unknown> = {};
  root[key] = next;
  return next;
}

function normalizeOpenAiBaseUrl(value: string): string {
  const raw = value.trim();
  const withProtocol = raw.startsWith("http") ? raw : `https://${raw}`;
  return withProtocol.endsWith("/v1")
    ? withProtocol
    : `${withProtocol.replace(/\/+$/, "")}/v1`;
}
