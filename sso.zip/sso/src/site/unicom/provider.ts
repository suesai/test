/**
 * 联通局点 实现：调用 getUnionAiKeyByResourceId，将 apiKey、llmName、llmUrl 存入凭证（内存加密）并使用 config.patch 写入 openclaw.json
 */
import type { SsoJsonConfig } from "../../config.js";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { SsoConfigError, SsoRuntimeError } from "../../errors.js";
import { addCredentialData } from "../../credential.js";
import { info, warn } from "../../log.js";
import { getUnionAiKey } from "./get-union-ai-key.js";

export async function runUnicomSso(params: {
  cfg: SsoJsonConfig;
  runtime: OpenClawPluginApi["runtime"];
}): Promise<void> {
  const { cfg, runtime } = params;

  // TODO: 测试用，后续删除
  info(`[unicom] rsaPublicKey: ${cfg.rsaPublicKey}`);
  info(`[unicom] rsaPrivateKey: ${cfg.rsaPrivateKey}`);

  const { apiKey, llmName, llmUrl } = await getUnionAiKey({
    baseUrl: cfg.baseUrl!,
    httpTimeoutMs: cfg.httpTimeoutMs!,
    httpRetryCount: cfg.httpRetryCount!,
    rsaPublicKey: cfg.rsaPublicKey!,
    rsaPrivateKey: cfg.rsaPrivateKey!,
  });

  // 联通局点失败时不退出，仅记录日志
  if (!apiKey || !llmName || !llmUrl) {
    warn("[unicom] API returned empty apiKey/llmName/llmUrl, continuing without SSO");
    return;
  }

  // 将凭证存入内存（加密）
  addCredentialData({
    apiKey,
    llmName,
    llmUrl,
  });

  // 写入 openclaw.json（仅联通局点需要）
  await writeUnicomConfig(runtime, { apiKey, llmName, llmUrl });
}

/**
 * 联通局点：重新执行认证逻辑，更新内存凭证和 openclaw.json
 */
export async function updateUnicomModelConfig(params: {
  cfg: SsoJsonConfig;
  runtime: OpenClawPluginApi["runtime"];
}): Promise<void> {
  const { cfg, runtime } = params;
  await runUnicomSso({ cfg, runtime });
}

/**
 * 将联通 AI 配置写入 openclaw.json
 */
async function writeUnicomConfig(
  runtime: OpenClawPluginApi["runtime"],
  config: { apiKey: string; llmName: string; llmUrl: string },
): Promise<void> {
  if (!runtime?.config) {
    warn("[unicom] runtime.config not available, skipping openclaw.json write");
    return;
  }

  try {
    // 读取当前配置快照（获取 baseHash 用于并发保护）
    const snapshot = await runtime.config.get({});
    const baseHash = snapshot.hash ?? undefined;

    // 提取 provider baseUrl
    const providerBaseUrl = normalizeOpenAiBaseUrl(config.llmUrl);

    const patchConfig = {
      models: {
        providers: {
          "default-model": {
            baseUrl: providerBaseUrl,
            apiKey: config.apiKey,
            models: [
              {
                id: config.llmName,
                name: config.llmName,
              },
            ],
          },
        },
      },
      agents: {
        defaults: {
          model: {
            primary: `default-model/${config.llmName}`,
          },
        },
      },
    };

    // 使用 config.patch 写入配置
    await runtime.config.patch({
      raw: JSON.stringify(patchConfig, null, 2),
      baseHash,
      note: "[unicom] update model config",
    });
    
    info(`[unicom] config patched via runtime.config.patch (provider=default-model, model=${config.llmName})`);
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    warn(`[unicom] failed to patch openclaw.json: ${errMsg}`);
    throw new SsoRuntimeError(`[unicom] config patch failed: ${errMsg}`, { cause: err });
  }
}

function normalizeOpenAiBaseUrl(value: string): string {
  const raw = value.trim();
  const withProtocol = raw.startsWith("http") ? raw : `https://${raw}`;
  return withProtocol.endsWith("/v1")
    ? withProtocol
    : `${withProtocol.replace(/\/+$/, "")}/v1`;
}
