/**
 * 联通 getUnionAiKeyByResourceId API 实现：`POST /openapi/user/getUnionAiKeyByResourceId`。
 * 使用 RSA 公钥加密请求参数，使用 RSA 私钥解密响应中的 appKey。
 */
import {
  constants,
  createPrivateKey,
  createPublicKey,
  privateDecrypt,
  publicEncrypt,
} from "node:crypto";
import os from "node:os";
import { SsoCryptoError, SsoHttpError, SsoNetworkError, SsoRuntimeError } from "../../errors.js";
import {
  debug,
  error,
  info,
  reportTelemetryEventToGateway,
  sensitiveHash,
  warn,
} from "../../log.js";
import {
  isRetryableHttpError,
  joinBasePath,
  jsonScalarString,
  responseMessageText,
  waitBeforeHttpRetry,
} from "../http-helpers.js";
import { getVmid } from "../../platform/vmid.js";

const REQUEST_PATH = "/openapi/user/getUnionAiKeyByResourceId";

/** 联通 getUnionAiKey 响应体 JSON 的 `code` 表示成功时的取值。 */
const UNICOM_SUCCESS_CODE = "200";

/**
 * 获取本机所有 IPv4 地址
 */
function getLocalIPv4Address(): string[] {
  const nets = os.networkInterfaces();
  const ips: string[] = [];

  for (const name of Object.keys(nets)) {
    const entries = nets[name];
    if (!entries) continue;

    for (const entry of entries) {
      if (!entry) continue;

      // Node 22: family 是 "IPv4" | "IPv6"
      const isIpv4 = entry.family === "IPv4";
      if (!isIpv4) continue;

      if (entry.internal) continue;
      if (typeof entry.address !== "string" || !entry.address) continue;
      if (entry.address === "127.0.0.1") continue;

      ips.push(entry.address);
    }
  }

  return [...new Set(ips)];
}

/**
 * 将 RSA 公钥 Base64 字符串转换为 PEM 格式
 */
function base64ToPem(base64: string, label: "PUBLIC KEY" | "PRIVATE KEY"): string {
  const trimmed = base64.trim();
  if (trimmed.includes("BEGIN") && trimmed.includes("END")) {
    return trimmed;
  }
  const lines = trimmed.match(/.{1,64}/g) ?? [trimmed];
  return [`-----BEGIN ${label}-----`, ...lines, `-----END ${label}-----`, ""].join("\n");
}

/**
 * 加密请求参数：{ resourceId, inIp, timestamp } → Base64(RSA 加密)
 * @returns 返回加密后的 base64 字符串
 */
function encryptRequestParam(params: {
  resourceId: string;
  inIp: string;
  timestamp: number;
  rsaPublicKey: string;
}): string {
  const payload = JSON.stringify({
    resourceId: params.resourceId,
    inIp: params.inIp,
    timestamp: params.timestamp,
  });
  
  const publicKeyPem = base64ToPem(params.rsaPublicKey, "PUBLIC KEY");
  const publicKey = createPublicKey(publicKeyPem);
  const encrypted = publicEncrypt(
    { key: publicKey, padding: constants.RSA_PKCS1_PADDING },
    Buffer.from(payload, "utf8"),
  );
  const encryptedBase64 = encrypted.toString("base64");
  return encryptedBase64;
}

/**
 * 解密 appKey：Base64(密文) → RSA 解密 → apiKey 明文
 */
function decryptAppKey(params: {
  encryptedBase64: string;
  rsaPrivateKey: string;
}): string {
  const privateKeyPem = base64ToPem(params.rsaPrivateKey, "PRIVATE KEY");
  const privateKey = createPrivateKey(privateKeyPem);
  const decrypted = privateDecrypt(
    { key: privateKey, padding: constants.RSA_PKCS1_PADDING },
    Buffer.from(params.encryptedBase64, "base64"),
  );
  const decryptedText = decrypted.toString("utf8").trim();
  return decryptedText;
}

function logRequest(params: {
  url: string;
  httpHeaders: Record<string, string>;
  requestBodyBeforeEncrypt: string;
  requestBodyAfterEncrypt: string;
  rsaPublicKey: string;
}): void {
  info("[Unicom] ========================================");
  info("[Unicom] getUnionAiKey 请求");
  info(`[Unicom] URL: ${params.url}`);
  info(`[Unicom] HTTP Headers: ${JSON.stringify(params.httpHeaders)}`);
  info(`[Unicom] Request Body (before encrypt): ${params.requestBodyBeforeEncrypt}`);
  info(`[Unicom] Request Body (after encrypt): ${params.requestBodyAfterEncrypt}`);
  debug(`[Unicom] RSA Public Key: ${params.rsaPublicKey}`);
  info(`[Unicom] RSA Public Key (masked): ${sensitiveHash("rsaPublicKey", params.rsaPublicKey)}`);
  info("[Unicom] ========================================");
}

function logResponse(params: {
  httpStatus: number;
  bodyText: string;
  durationMs: number;
  rsaPrivateKey: string;
}): void {
  info("[Unicom] ========================================");
  info("[Unicom] getUnionAiKey 响应");
  info(`[Unicom] HTTP Status: ${params.httpStatus}, Duration: ${params.durationMs}ms`);
  info(`[Unicom] Body: ${params.bodyText}`);
  debug(`[Unicom] RSA Private Key: ${params.rsaPrivateKey}`);
  info(`[Unicom] RSA Private Key (masked): ${sensitiveHash("rsaPrivateKey", params.rsaPrivateKey)}`);
  info("[Unicom] ========================================");
}

async function reportGetUnionAiKeyResultTelemetry(params: {
  durationMs: number;
  ok: boolean;
  reason?: string;
  httpStatus?: number;
  llmName?: string;
  llmUrl?: string;
  apiKeyMasked?: string;
}): Promise<void> {
  await reportTelemetryEventToGateway({
    event_type: "sso",
    sso_site: "unicom",
    sso_api: "getUnionAiKey",
    sso_ok: params.ok,
    sso_duration_ms: params.durationMs,
    ...(params.reason ? { sso_failure_reason: params.reason } : {}),
    ...(params.httpStatus !== undefined ? { sso_http_status: params.httpStatus } : {}),
    ...(params.llmName !== undefined ? { sso_llm_name: params.llmName } : {}),
    ...(params.llmUrl !== undefined ? { sso_llm_url: params.llmUrl } : {}),
    ...(params.apiKeyMasked !== undefined ? { sso_api_key_masked: params.apiKeyMasked } : {}),
  });
}

export async function getUnionAiKey(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  httpRetryCount: number;
  rsaPublicKey: string;
  rsaPrivateKey: string;
}): Promise<{ apiKey: string; llmName: string; llmUrl: string }> {
  const max = params.httpRetryCount;
  for (let i = 0; i < max; i++) {
    if (i > 0) {
      await waitBeforeHttpRetry();
      warn(`[Unicom] getUnionAiKey will retry (attempt ${i + 1}/${max}) after transient failure`);
    }
    try {
      return await getUnionAiKeyOnce(params);
    } catch (e) {
      if (i < max - 1 && isRetryableHttpError(e)) {
        continue;
      }
      const errMsg = e instanceof Error ? e.message : String(e);
      if (i === max - 1) {
        error(
          `[Unicom] getUnionAiKey: 重试已用尽 (共 ${max} 次)，仍失败，即将向上抛出：${errMsg}`,
        );
      } else {
        error(
          `[Unicom] getUnionAiKey: 第 ${i + 1}/${max} 次失败，错误不可重试或非瞬时，即将抛出：${errMsg}`,
        );
      }
      throw e;
    }
  }
  throw new SsoRuntimeError("[unicom] getUnionAiKey: retry loop ended without return");
}

async function getUnionAiKeyOnce(params: {
  baseUrl: string;
  httpTimeoutMs: number;
  rsaPublicKey: string;
  rsaPrivateKey: string;
}): Promise<{ apiKey: string; llmName: string; llmUrl: string }> {
  // 在内部获取 vmid 和 ip
  const vmid = getVmid();
  const ips = getLocalIPv4Address();
  // resourceId 使用 vmid，inIp 使用 "ip1,ip2,..." 格式
  const resourceId = vmid;
  const inIp = ips.join(",");

  const url = joinBasePath(params.baseUrl, REQUEST_PATH);
  const timestamp = Date.now();

  // 加密前的原始 payload
  const requestBodyBeforeEncrypt = JSON.stringify({
    resourceId,
    inIp,
    timestamp,
  });

  // 加密请求参数
  const parameter = encryptRequestParam({
    resourceId,
    inIp,
    timestamp,
    rsaPublicKey: params.rsaPublicKey,
  });

  // 加密后的 HTTP body（真正发送给服务器的 JSON）
  const requestBodyAfterEncrypt = JSON.stringify({ parameter });
  const httpHeaders: Record<string, string> = {
    "Content-Type": "application/json",
    "Device-Type": "pc",
  };

  logRequest({
    url,
    httpHeaders,
    requestBodyBeforeEncrypt,
    requestBodyAfterEncrypt,
    rsaPublicKey: params.rsaPublicKey,
  });

  const started = Date.now();
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: httpHeaders,
      body: requestBodyAfterEncrypt,
      signal: AbortSignal.timeout(params.httpTimeoutMs),
    });
  } catch (e) {
    const durationMs = Date.now() - started;
    const reason = `network: ${e instanceof Error ? e.message : String(e)}`;
    warn(`[Unicom] getUnionAiKey failed: ${reason}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({ ok: false, durationMs, reason });
    throw new SsoNetworkError(`[Unicom] getUnionAiKey fetch failed: ${e instanceof Error ? e.message : String(e)}`, {
      cause: e,
    });
  }

  const httpStatus = res.status;
  const text = await res.text();
  const durationMs = Date.now() - started;
  logResponse({ httpStatus, bodyText: text, durationMs, rsaPrivateKey: params.rsaPrivateKey });

  let json: unknown;
  try {
    json = text ? JSON.parse(text) : null;
  } catch (e) {
    warn(`[Unicom] getUnionAiKey failed: invalid_json_body, httpStatus=${httpStatus}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "invalid_json_body",
    });
    throw new SsoHttpError(`[Unicom] getUnionAiKey: response is not JSON (${httpStatus})`, httpStatus, { cause: e });
  }

  const o = json as Record<string, unknown> | null;
  if (!o) {
    warn(`[Unicom] getUnionAiKey failed: empty_body, httpStatus=${httpStatus}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "empty_body",
    });
    throw new SsoHttpError("[Unicom] getUnionAiKey: empty response", httpStatus);
  }

  if (!res.ok) {
    const codeStr = jsonScalarString(o.code);
    const msg = responseMessageText(o.msg);
    warn(`[Unicom] getUnionAiKey failed: http_not_2xx, httpStatus=${httpStatus}, code=${codeStr}, msg=${msg}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `http_not_2xx code=${codeStr} msg=${msg}`,
    });
    throw new SsoHttpError(`[Unicom] getUnionAiKey: HTTP ${httpStatus} code=${codeStr} ${msg}`, httpStatus);
  }

  const codeStr = jsonScalarString(o.code);
  const success = o.success === true;
  if (codeStr !== UNICOM_SUCCESS_CODE || !success) {
    const msg = responseMessageText(o.msg);
    warn(`[Unicom] getUnionAiKey failed: api_code 非 ${UNICOM_SUCCESS_CODE} 或 success=false, httpStatus=${httpStatus}, code=${codeStr}, success=${success}, msg=${msg}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: `api_code_non_success code=${codeStr} success=${success} msg=${msg}`,
    });
    throw new SsoRuntimeError(`[Unicom] getUnionAiKey: API error code=${codeStr} success=${success} (${msg})`);
  }

  // 提取 data 字段
  const data = o.data;
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    warn(`[Unicom] getUnionAiKey failed: missing_or_invalid_data_field, httpStatus=${httpStatus}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "missing_or_invalid_data_field",
    });
    throw new SsoHttpError("[Unicom] getUnionAiKey: data field missing or invalid", httpStatus);
  }

  const dataObj = data as Record<string, unknown>;
  const llmName = jsonScalarString(dataObj.llmName).trim();
  const llmUrl = jsonScalarString(dataObj.llmUrl).trim();
  const encryptedAppKey = jsonScalarString(dataObj.appKey).trim();

  if (!llmName || !llmUrl || !encryptedAppKey) {
    warn(`[Unicom] getUnionAiKey failed: missing_llmName_llmUrl_appKey, httpStatus=${httpStatus}, duration=${durationMs}ms, hasLlmName=${!!llmName}, hasLlmUrl=${!!llmUrl}, hasAppKey=${!!encryptedAppKey}`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "missing_llmName_llmUrl_appKey",
    });
    throw new SsoHttpError("[Unicom] getUnionAiKey: llmName/llmUrl/appKey missing", httpStatus);
  }

  // 解密 appKey
  let apiKey: string;
  try {
    apiKey = decryptAppKey({
      encryptedBase64: encryptedAppKey,
      rsaPrivateKey: params.rsaPrivateKey,
    });
  } catch (e) {
    const reason = `decrypt: ${e instanceof Error ? e.message : String(e)}`;
    warn(`[Unicom] getUnionAiKey failed: ${reason}, httpStatus=${httpStatus}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason,
    });
    throw new SsoCryptoError(`[Unicom] getUnionAiKey: decrypt appKey failed: ${e instanceof Error ? e.message : String(e)}`, {
      cause: e,
    });
  }

  if (!apiKey) {
    warn(`[Unicom] getUnionAiKey failed: decrypted_apiKey_empty, httpStatus=${httpStatus}, duration=${durationMs}ms`);
    await reportGetUnionAiKeyResultTelemetry({
      ok: false,
      durationMs,
      httpStatus,
      reason: "decrypted_apiKey_empty",
    });
    throw new SsoHttpError("[Unicom] getUnionAiKey: decrypted apiKey is empty", httpStatus);
  }

  info(`[Unicom] apiKey (masked): ${sensitiveHash("apiKey", apiKey)}`);
  debug(`[Unicom] apiKey: ${apiKey}`);
  await reportGetUnionAiKeyResultTelemetry({
    ok: true,
    durationMs,
    httpStatus,
    llmName,
    llmUrl,
    apiKeyMasked: sensitiveHash("apiKey", apiKey),
  });

  return { apiKey, llmName, llmUrl };
}
