import type { SsoJsonConfig } from "../config.js";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk/core";
import { SsoConfigError } from "../errors.js";
import { runHangyanSso } from "./hangyan/provider.js";
import { runUnicomSso } from "./unicom/provider.js";
import { updateHangyanModelConfig } from "./hangyan/provider.js";
import { updateUnicomModelConfig } from "./unicom/provider.js";

export async function runSite(
  cfg: SsoJsonConfig,
  runtime: OpenClawPluginApi["runtime"],
): Promise<void> {
  const site = cfg.site.trim().toLowerCase();
  if (site === "hangyan") {
    await runHangyanSso({ cfg });
    return;
  }
  if (site === "unicom") {
    await runUnicomSso({ cfg, runtime });
    return;
  }
  throw new SsoConfigError(`sso.json: unknown site "${cfg.site}"`);
}

export async function updateModelConfig(
  params: { cfg: SsoJsonConfig; runtime: OpenClawPluginApi["runtime"] },
): Promise<void> {
  const { cfg, runtime } = params;

  const site = cfg.site.trim().toLowerCase();
  if (site === "hangyan") {
    await updateHangyanModelConfig(cfg);
    return;
  }
  if (site === "unicom") {
    await updateUnicomModelConfig({ cfg, runtime });
    return;
  }
  throw new SsoConfigError(`updateModelConfig: unknown site "${cfg.site}"`);
}
