import { existsSync } from "node:fs";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { error, info, initLog, warn } from "./src/log.js";
import { formatSsoFailure } from "./src/errors.js";
import { clearCredential, getCredentialData, type CredentialData } from "./src/credential.js";
import { runSite, updateModelConfig } from "./src/site/index.js";
import { getSsoConfig, loadSsoJson } from "./src/config.js";
import type { SsoJsonConfig } from "./src/config.js";

export default definePluginEntry({
  id: "sso",
  name: "Co-Claw desktop SSO",
  description: "Co-Claw desktop SSO (Hangyan and extensible site providers)",
  register(api) {
    initLog();
    clearCredential();

    // 直接使用 api.rootDir，这是插件的标准根目录
    const configPath = api.rootDir + "/sso.json";
    // 先检查配置文件是否存在，不存在则直接跳过 SSO
    if (!existsSync(configPath)) {
      warn(`skipped due to missing configuration file: ${configPath}`);
      return;
    }

    // 在插件注册时预加载配置文件并缓存，避免后续重复读取
    try {
      loadSsoJson(configPath);
    } catch (err) {
      const { code, message } = formatSsoFailure(err);
      error(`configuration load failed code=${code} message=${message}`);
      process.exit(1);
    }

    api.on("gateway_start", async () => {
      try {
        const cfg = getSsoConfig();
        if (!cfg) {
          error("gateway_start: configuration not loaded");
          process.exit(1);
        }
        info(`gateway_start: starting SSO authentication for site=${cfg.site}`);
        await runSite(cfg, api.runtime);
        info(`gateway_start: SSO authentication completed for site=${cfg.site}`);
      } catch (err) {
        const { code, message } = formatSsoFailure(err);
        error(`failure code=${code} message=${message}`);
        process.exit(1);
      }
    });

    api.registerGatewayMethod("sso.getCredentialData", async ({ respond }) => {
      try {
        const cfg = getSsoConfig();
        if (!cfg) {
          warn("sso.getCredentialData: SSO not ready (config missing or flow not completed)");
          respond(false, { error: "SSO not ready" });
          return;
        }
        const creds = getCredentialData();
        respond(true, creds);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        error(`sso.getCredentialData failed: ${errorMsg}`);
        respond(false, { error: errorMsg });
      }
    });

    api.registerGatewayMethod("sso.updateModelConfig", async ({ respond }) => {
      try {
        const cfg = getSsoConfig();
        if (!cfg) {
          warn("sso.updateModelConfig: SSO not ready (config missing or flow not completed)");
          respond(false, { error: "SSO not ready" });
          return;
        }
        info("sso.updateModelConfig: updating model configuration");
        await updateModelConfig({ cfg, runtime: api.runtime });
        info("sso.updateModelConfig: completed successfully");
        respond(true, {});
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        error(`sso.updateModelConfig failed: ${errorMsg}`);
        respond(false, { error: errorMsg });
      }
    });
  },
});

// 对外导出类型（供其他插件或模块使用）
export type { CredentialData as SsoCredentialData };
