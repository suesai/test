import { fileURLToPath } from "node:url";
import path from "node:path";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { error, warn } from "./src/log.js";
import { checkIsReady, formatSsoFailure, runSso } from "./src/run-sso.js";
import { getCredentialData, type CredentialData } from "./src/credential.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default definePluginEntry({
  id: "sso",
  name: "Co-Claw desktop SSO",
  description: "Co-Claw desktop SSO (Hangyan and extensible site providers)",
  register(api) {
    const pluginRootDir = api.rootDir ?? __dirname;

    api.on("gateway_start", async () => {
      try {
        await runSso({ pluginRootDir, runtime: api.runtime });
      } catch (err) {
        const { code, message } = formatSsoFailure(err);
        error(`SSO failure code=${code} message=${message}`);
        process.exit(1);
      }
    });

    // 注册 Gateway RPC 方法，供其他插件跨进程调用
    api.registerGatewayMethod("sso.getCredentialData", async ({ respond }) => {
      try {
        if (!checkIsReady()) {
          warn("sso.getCredentialData: SSO not ready (config missing or flow not completed)");
          respond(false, { error: "SSO not ready" });
          return;
        }
        const creds = getCredentialData();
        respond(true, creds);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        error(`sso.getCredentialData failed: ${errorMsg}`);
        respond(false, { error: errorMsg });
      }
    });
  },
});

// 对外导出类型（供其他插件或模块使用）
export type { CredentialData as SsoCredentialData };
